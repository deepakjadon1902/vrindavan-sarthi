import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuthStore } from '@/store/authStore';
import {
  LayoutDashboard, Hotel, BedDouble, LogOut, Menu, X, ClipboardList, CreditCard, Car,
  Bell, UserCog, Landmark, ShieldCheck, FileText, CalendarDays,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { useBookingStore } from '@/store/bookingStore';
import { useSettingsStore } from '@/store/settingsStore';
import { APP_LOGO_URL } from '@/lib/brand';
import BookingAlarmManager from '@/components/notifications/BookingAlarmManager';
import AndroidApkDownloadPrompt from '@/components/AndroidApkDownloadPrompt';

const sidebarLinks = [
  { name: 'Dashboard', path: '/partner', icon: LayoutDashboard },
  { name: 'My Hotels', path: '/partner/hotels', icon: Hotel },
  { name: 'Inventory', path: '/partner/inventory', icon: BedDouble },
  { name: 'Rates', path: '/partner/rates', icon: CalendarDays },
  { name: 'Availability Calendar', path: '/partner/availability', icon: CalendarDays },
  { name: 'Bookings', path: '/partner/bookings', icon: ClipboardList },
  { name: 'Payments', path: '/partner/payments', icon: CreditCard },
  { name: 'Bank Details', path: '/partner/bank-details', icon: Landmark },
  { name: 'Partner T&C', path: '/partner/terms', icon: FileText },
  { name: 'Profile Settings', path: '/partner/profile-settings', icon: UserCog },
  { name: 'Notices', path: '/partner/communications', icon: Bell },
];

const PartnerLayout = () => {
  const { user, token, logout, refreshMe } = useAuthStore();
  const { partnerBookings, fetchPartnerBookings } = useBookingStore();
  const settings = useSettingsStore((s) => s.settings);
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    if (!token) return;
    void refreshMe();
  }, [refreshMe, token]);

  useEffect(() => {
    if (!token || user?.partnerStatus !== 'approved') return;
    void fetchPartnerBookings();
  }, [fetchPartnerBookings, token, user?.partnerStatus]);

  const bookingCount = partnerBookings.length;
  const isApproved = user?.partnerStatus === 'approved';
  const isStatusPage = location.pathname === '/partner' || location.pathname === '/partner/profile-settings';
  const showApprovalGate = user?.role === 'partner' && !isApproved && !isStatusPage;

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen flex panel-shell">
      <aside
        className={`fixed lg:static inset-y-0 left-0 z-50 w-64 panel-sidebar flex flex-col border-r border-brand-gold/20 transition-transform duration-300 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex justify-center p-5 border-b border-brand-gold/20">
          <div className="flex items-center justify-center">
            <img src={APP_LOGO_URL} alt={settings.siteName} className="h-12 w-12 rounded-full object-cover border border-brand-gold/30" />
          </div>
        </div>

        <nav className="flex-1 py-4 overflow-y-auto">
          {sidebarLinks.map((link) => {
            const isActive = location.pathname === link.path;
            const isBookings = link.path === '/partner/bookings';
            return (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setSidebarOpen(false)}
                className={`flex items-center gap-3 px-6 py-3 font-body text-sm transition-colors ${
                  isActive
                    ? 'bg-brand-gold text-brand-black border-r-2 border-white'
                    : 'text-white/70 hover:text-white hover:bg-white/10'
                }`}
              >
                <link.icon size={18} />
                {link.name}
                {isBookings && bookingCount > 0 && (
                  <span className="ml-auto bg-brand-saffron text-foreground text-[10px] font-bold px-1.5 py-0.5 rounded-full">{bookingCount}</span>
                )}
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-brand-gold/20">
          <div className="flex items-center gap-3 mb-3 px-2">
            <div className="w-8 h-8 rounded-full bg-brand-gold/20 flex items-center justify-center">
              <span className="text-brand-gold font-body text-xs font-bold">
                {user?.name?.charAt(0) || 'P'}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-body text-xs text-white truncate">{user?.name}</p>
              <p className="font-body text-[10px] text-white/55 truncate">{user?.businessName}</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 w-full px-4 py-2 font-body text-xs text-white/70 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
          >
            <LogOut size={14} />
            Sign Out
          </button>
        </div>
      </aside>

      {sidebarOpen && <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      <div className="flex-1 flex flex-col min-w-0">
        <header className="panel-hero min-h-16 sm:min-h-20 border-b border-brand-gold/20 flex items-center justify-between gap-3 px-3 sm:px-4 lg:px-8">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="lg:hidden rounded-lg p-2 text-white hover:bg-white/10">
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          <h1 className="min-w-0 flex-1 truncate font-heading text-lg font-semibold text-white sm:text-2xl">
            {sidebarLinks.find((l) => l.path === location.pathname)?.name || 'Partner'}
          </h1>
          <BookingAlarmManager
            token={token}
            user={user}
            enabled={user?.role === 'partner' && user?.partnerStatus === 'approved'}
            viewPath="/partner/bookings"
            onNewBooking={() => void fetchPartnerBookings()}
          />
        </header>
        <main className="flex-1 overflow-y-auto p-3 sm:p-4 lg:p-8">
          <AndroidApkDownloadPrompt role="partner" />
          {showApprovalGate ? (
            <div className="max-w-3xl bg-card border border-border rounded-xl p-6">
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-xl bg-brand-saffron/10 flex items-center justify-center shrink-0">
                  <ShieldCheck size={22} className="text-brand-saffron" />
                </div>
                <div>
                  <h2 className="font-heading text-xl font-semibold text-foreground">Admin verification required</h2>
                  <p className="font-body text-sm text-muted-foreground mt-2">
                    Your partner account is currently {user?.partnerStatus || 'pending'}. Admin must verify your business details and legal documents before you can list hotels, inventory, cabs, or other properties.
                  </p>
                  <button onClick={() => navigate('/partner')} className="mt-4 btn-gold px-5 py-2.5 rounded-lg text-sm">
                    Back to Dashboard
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <Outlet />
          )}
        </main>
      </div>
    </div>
  );
};

export default PartnerLayout;
