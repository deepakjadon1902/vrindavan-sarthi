import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { IndianRupee, Plus, Pencil, Trash2, Search, X, Image as ImageIcon } from 'lucide-react';
import { toast } from 'sonner';
import { api, withAuth } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';
import { publishAppEvent } from '@/lib/broadcast';
import { getApiErrorMessage } from '@/lib/apiError';
import { BRAJ_LANDMARK_PLACE_NAMES, OTHER_LANDMARK_OPTION, getLandmarkOptionsForPlace, getLandmarkPlaceForListing } from '@/lib/landmarks';
import { PropertyTermsEditor, hasPropertyTermsText, normalizePropertyTerms, type PropertyTermsValue } from '@/components/shared/PropertyTerms';
import { isDharamshalaType, propertyTypeOptions, type StayPropertyType } from '@/lib/propertyTypes';
import RecordPagination, { useRecordPagination } from '@/components/shared/RecordPagination';

interface PartnerHotel {
  _id: string;
  name: string;
  propertyType?: StayPropertyType;
  location: string;
  rating?: number;
  image?: string;
  images?: string[];
  description?: string;
  amenities?: string[];
  googleMapLink?: string;
  nearestTemple?: string;
  checkInTime?: string;
  checkOutTime?: string;
  hotelGstin?: string;
  showPrices?: boolean;
  dharamshalaPaymentMode?: 'pay_at_dharamshala' | 'full_online' | 'request_only';
  dharamshalaPlatformFeeEnabled?: boolean;
  dharamshalaServiceFee?: number;
  dharamshalaResponseTimeoutMinutes?: number;
  taxEnabled?: boolean;
  taxPercent?: number;
  gstMode?: 'manual' | 'automatic';
  petsAllowed?: boolean;
  propertyTerms?: PropertyTermsValue;
  status: 'active' | 'inactive';
  approvalStatus: 'pending' | 'approved' | 'rejected';
  adminRemarks?: string;
  createdAt: string;
}

const PartnerAddHotel = () => {
  const navigate = useNavigate();
  const token = useAuthStore((s) => s.token);
  const user = useAuthStore((s) => s.user);
  const [searchParams, setSearchParams] = useSearchParams();
  const getDefaultForm = () => ({
    name: user?.businessName || '',
    propertyType: 'hotel' as PartnerHotel['propertyType'],
    place: getLandmarkPlaceForListing(undefined, user?.businessAddress),
    location: user?.businessAddress || '',
    rating: '',
    description: user?.businessDescription || '',
    amenities: '',
    googleMapLink: '',
    nearestTemple: '',
    checkInTime: '12:00',
    checkOutTime: '11:00',
    hotelGstin: user?.gstNumber || '',
    taxEnabled: Boolean(user?.gstNumber),
    taxPercent: '12',
    gstMode: 'automatic' as 'manual' | 'automatic',
    showPrices: true,
    dharamshalaPaymentMode: 'pay_at_dharamshala' as const,
    dharamshalaPlatformFeeEnabled: true,
    dharamshalaServiceFee: '79',
    dharamshalaResponseTimeoutMinutes: '30',
    petsAllowed: false,
    propertyTerms: normalizePropertyTerms(),
    images: [] as string[],
  });

  const [items, setItems] = useState<PartnerHotel[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const [form, setForm] = useState(getDefaultForm);

  const reusablePropertyTerms = () => {
    const saved = items.find((item) => hasPropertyTermsText(item.propertyTerms))?.propertyTerms;
    return normalizePropertyTerms(saved);
  };

  const load = async () => {
    if (!token) return;
    try {
      setIsLoading(true);
      const res = await api.get('/partner/my-listings', { ...withAuth(token), params: { limit: 500 } });
      const hotels = Array.isArray(res.data?.data?.hotels) ? res.data.data.hotels : [];
      setItems(hotels);
    } catch (err: unknown) {
      toast.error(getApiErrorMessage(err, 'Failed to load your hotels'));
      setItems([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  useEffect(() => {
    const editId = searchParams.get('edit');
    if (!editId) return;
    const target = items.find((i) => i._id === editId);
    if (!target) return;

    setForm({
      name: target.name || '',
      propertyType: target.propertyType || 'hotel',
      place: getLandmarkPlaceForListing(target.nearestTemple, target.location),
      location: target.location || '',
      rating: String(target.rating ?? ''),
      description: target.description || '',
      amenities: (target.amenities || []).join(', '),
      googleMapLink: target.googleMapLink || '',
      nearestTemple: target.nearestTemple || '',
      checkInTime: target.checkInTime || '12:00',
      checkOutTime: target.checkOutTime || '11:00',
      hotelGstin: target.hotelGstin || user?.gstNumber || '',
      taxEnabled: Boolean(target.taxEnabled),
      taxPercent: String(target.taxPercent ?? 12),
      gstMode: target.gstMode || 'automatic',
      showPrices: target.showPrices !== false,
      dharamshalaPaymentMode: target.dharamshalaPaymentMode || 'pay_at_dharamshala',
      dharamshalaPlatformFeeEnabled: target.dharamshalaPlatformFeeEnabled !== false,
      dharamshalaServiceFee: String(target.dharamshalaServiceFee ?? 79),
      dharamshalaResponseTimeoutMinutes: String(target.dharamshalaResponseTimeoutMinutes ?? 30),
      petsAllowed: Boolean(target.petsAllowed),
      propertyTerms: normalizePropertyTerms(target.propertyTerms),
      images: [target.image, ...(target.images || [])].filter(Boolean) as string[],
    });
    setEditingId(target._id);
    setShowForm(true);

    const next = new URLSearchParams(searchParams);
    next.delete('edit');
    setSearchParams(next, { replace: true });
  }, [items, searchParams, setSearchParams, user?.gstNumber]);

  const resetForm = () => {
    setForm(getDefaultForm());
    setEditingId(null);
    setShowForm(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setForm((prev) => ({ ...prev, images: [...prev.images, reader.result as string] }));
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (idx: number) => {
    setForm((prev) => ({ ...prev, images: prev.images.filter((_, i) => i !== idx) }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    const nearestTemple = form.nearestTemple === OTHER_LANDMARK_OPTION ? '' : form.nearestTemple.trim();
    if (!form.name || !form.location || !nearestTemple) {
      toast.error('Fill required fields');
      return;
    }

    const payload = {
      name: form.name,
      propertyType: form.propertyType,
      location: form.location,
      rating: Number(form.rating || 0),
      description: form.description,
      googleMapLink: form.googleMapLink.trim() || form.location.trim(),
      nearestTemple,
      checkInTime: form.checkInTime || '12:00',
      checkOutTime: form.checkOutTime || '11:00',
      hotelGstin: form.hotelGstin.trim(),
      taxEnabled: isDharamshalaType(form.propertyType) ? false : Boolean(form.hotelGstin.trim()) && Boolean(form.taxEnabled),
      taxPercent: isDharamshalaType(form.propertyType) ? 0 : form.gstMode === 'manual' ? Number(form.taxPercent || 12) : 0,
      gstMode: isDharamshalaType(form.propertyType) ? 'manual' : form.gstMode,
      showPrices: Boolean(form.showPrices),
      dharamshalaPaymentMode: form.dharamshalaPaymentMode,
      dharamshalaPlatformFeeEnabled: Boolean(form.dharamshalaPlatformFeeEnabled),
      dharamshalaServiceFee: Number(form.dharamshalaServiceFee || 0),
      dharamshalaResponseTimeoutMinutes: Number(form.dharamshalaResponseTimeoutMinutes || 30),
      amenities: form.amenities
        .split(',')
        .map((a) => a.trim())
        .filter(Boolean),
      petsAllowed: Boolean(form.petsAllowed),
      propertyTerms: form.propertyTerms,
      contactPhone: user?.businessPhone || user?.phone || '',
      contactEmail: user?.businessEmail || user?.email || '',
      fullAddress: user?.businessAddress || form.location,
      businessName: user?.businessName || form.name,
      image: form.images[0] || '/placeholder.svg',
      images: form.images.slice(1),
    };

    try {
      if (editingId) {
        const res = await api.put(`/partner/hotels/${editingId}`, payload, withAuth(token));
        const updated = res.data?.data as PartnerHotel;
        setItems((prev) => prev.map((h) => (h._id === editingId ? updated : h)));
        toast.success('Listing resubmitted for approval');
      } else {
        const res = await api.post('/partner/hotels', payload, withAuth(token));
        const created = res.data?.data as PartnerHotel;
        setItems((prev) => [created, ...prev]);
        toast.success('Listing submitted for admin approval');
      }
      publishAppEvent('listing:changed');
      resetForm();
    } catch {
      toast.error(editingId ? 'Update failed' : 'Submit failed');
    }
  };

  const handleEdit = (item: PartnerHotel) => {
    setForm({
      name: item.name || '',
      propertyType: item.propertyType || 'hotel',
      place: getLandmarkPlaceForListing(item.nearestTemple, item.location),
      location: item.location || '',
      rating: String(item.rating ?? ''),
      description: item.description || '',
      amenities: (item.amenities || []).join(', '),
      googleMapLink: item.googleMapLink || '',
      nearestTemple: item.nearestTemple || '',
      checkInTime: item.checkInTime || '12:00',
      checkOutTime: item.checkOutTime || '11:00',
      hotelGstin: item.hotelGstin || user?.gstNumber || '',
      taxEnabled: Boolean(item.taxEnabled),
      taxPercent: String(item.taxPercent ?? 12),
      gstMode: item.gstMode || 'automatic',
      showPrices: item.showPrices !== false,
      dharamshalaPaymentMode: item.dharamshalaPaymentMode || 'pay_at_dharamshala',
      dharamshalaPlatformFeeEnabled: item.dharamshalaPlatformFeeEnabled !== false,
      dharamshalaServiceFee: String(item.dharamshalaServiceFee ?? 79),
      dharamshalaResponseTimeoutMinutes: String(item.dharamshalaResponseTimeoutMinutes ?? 30),
      petsAllowed: Boolean(item.petsAllowed),
      propertyTerms: normalizePropertyTerms(item.propertyTerms),
      images: [item.image, ...(item.images || [])].filter(Boolean) as string[],
    });
    setEditingId(item._id);
    setShowForm(true);
  };

  const handlePrices = (item: PartnerHotel) => {
    navigate(`/partner/inventory?hotelId=${encodeURIComponent(item._id)}`);
  };

  const handleDelete = async (id: string) => {
    if (!token) return;
    try {
      await api.delete(`/partner/hotels/${id}`, withAuth(token));
      setItems((prev) => prev.filter((h) => h._id !== id));
      toast.success('Deleted');
      publishAppEvent('listing:changed');
    } catch {
      toast.error('Delete failed');
    } finally {
      setDeleteConfirm(null);
    }
  };

  const statusBadge = (status: string) => {
    if (status === 'approved') return 'bg-brand-green/10 text-brand-green';
    if (status === 'rejected') return 'bg-destructive/10 text-destructive';
    return 'bg-brand-saffron/10 text-brand-saffron';
  };

  const landmarkOptionsForPlace = getLandmarkOptionsForPlace(form.place);
  const nearestTempleSelectValue = form.nearestTemple && landmarkOptionsForPlace.includes(form.nearestTemple)
    ? form.nearestTemple
    : form.nearestTemple
      ? OTHER_LANDMARK_OPTION
      : '';

  const handlePlaceChange = (place: string) => {
    const shouldUsePlaceAsLocation = !form.location.trim() || form.location.trim() === form.place;
    setForm({
      ...form,
      place,
      location: place && place !== OTHER_LANDMARK_OPTION && shouldUsePlaceAsLocation ? place : form.location,
      nearestTemple: '',
    });
  };

  const filtered = useMemo(
    () =>
      items.filter(
        (h) =>
          h.name.toLowerCase().includes(search.toLowerCase()) ||
          h.location.toLowerCase().includes(search.toLowerCase())
      ).sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()),
    [items, search]
  );
  const { page, setPage, pageItems } = useRecordPagination(filtered, [search]);
  const isApproved = user?.partnerStatus === 'approved';
  const hasHotel = items.length > 0;
  const isDharamshalaForm = isDharamshalaType(form.propertyType);
  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-heading text-xl font-bold text-foreground">My Stay Listing</h2>
        <p className="font-body text-xs text-muted-foreground">
          Submit one hotel, home stay, guest house, or dharamshala for approval. Add room types and room numbers from Inventory after the listing exists.
        </p>
        {user?.partnerStatus && (
          <p className="font-body text-xs text-muted-foreground mt-1">Partner status: {user.partnerStatus}</p>
        )}
      </div>

      {!isApproved && (
        <div className="bg-brand-saffron/10 border border-brand-saffron/30 rounded-xl p-4">
          <p className="font-body text-sm font-medium text-foreground">Admin verification required</p>
          <p className="font-body text-xs text-muted-foreground mt-1">
            Your partner account is {user?.partnerStatus || 'pending'}. You can submit listings after admin verifies your legal documents.
          </p>
        </div>
      )}

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search hotels..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 rounded-lg border border-border bg-card font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
          />
        </div>
        <button
          disabled={!isApproved || hasHotel}
          onClick={() => {
            setForm({ ...getDefaultForm(), propertyTerms: reusablePropertyTerms() });
            setEditingId(null);
            setShowForm(true);
          }}
          className="btn-gold px-5 py-2.5 rounded-lg text-sm flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
            <Plus size={16} /> {hasHotel ? 'Listing Already Submitted' : 'Submit Listing'}
        </button>
      </div>

      {hasHotel && (
        <div className="bg-brand-green/10 border border-brand-green/25 rounded-xl p-4">
          <p className="font-body text-sm font-medium text-foreground">One stay listing is active for your partner account.</p>
          <p className="font-body text-xs text-muted-foreground mt-1">Use Inventory to add multiple room types and room numbers for this listing.</p>
        </div>
      )}

      {showForm && (
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-heading text-lg font-semibold">{editingId ? 'Edit & Resubmit' : 'Submit New Listing'}</h3>
            <button onClick={resetForm} className="text-muted-foreground hover:text-foreground">
              <X size={20} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Property Name *</label>
                <input
                  type="text"
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                />
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Listing Type *</label>
                <select
                  required
                  value={form.propertyType}
                  onChange={(e) => setForm({ ...form, propertyType: e.target.value as PartnerHotel['propertyType'] })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                >
                  {propertyTypeOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
                </select>
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Place *</label>
                <select
                  required
                  value={form.place}
                  onChange={(e) => handlePlaceChange(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                >
                  <option value="">Select place</option>
                  {BRAJ_LANDMARK_PLACE_NAMES.map((place) => <option key={place} value={place}>{place}</option>)}
                  <option value={OTHER_LANDMARK_OPTION}>{OTHER_LANDMARK_OPTION}</option>
                </select>
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Location / Full Address *</label>
                <input
                  type="text"
                  required
                  value={form.location}
                  onChange={(e) => setForm({ ...form, location: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                  placeholder="Area, road, or complete address"
                />
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Rating</label>
                <input
                  type="number"
                  min="0"
                  max="5"
                  step="0.1"
                  value={form.rating}
                  onChange={(e) => setForm({ ...form, rating: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                />
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Map Location / Google Link</label>
                <input
                  type="text"
                  value={form.googleMapLink}
                  onChange={(e) => setForm({ ...form, googleMapLink: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                  placeholder="Leave blank to use the hotel location automatically"
                />
                <p className="font-body text-xs text-muted-foreground mt-1">If blank, the public map uses the Location field.</p>
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Nearby Landmark / Temple *</label>
                <select
                  required
                  value={nearestTempleSelectValue}
                  onChange={(e) => setForm({ ...form, nearestTemple: e.target.value === OTHER_LANDMARK_OPTION ? OTHER_LANDMARK_OPTION : e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                >
                  <option value="">{form.place ? 'Select nearby landmark / temple' : 'Select place first'}</option>
                  {landmarkOptionsForPlace.map((name) => <option key={name} value={name}>{name}</option>)}
                  <option value={OTHER_LANDMARK_OPTION}>{OTHER_LANDMARK_OPTION}</option>
                </select>
                {nearestTempleSelectValue === OTHER_LANDMARK_OPTION && (
                  <input
                    type="text"
                    required
                    value={form.nearestTemple === OTHER_LANDMARK_OPTION ? '' : form.nearestTemple}
                    onChange={(e) => setForm({ ...form, nearestTemple: e.target.value.trimStart() || OTHER_LANDMARK_OPTION })}
                    className="mt-2 w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                    placeholder="Enter landmark manually"
                  />
                )}
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Check-in Time *</label>
                <input
                  type="time"
                  required
                  value={form.checkInTime}
                  onChange={(e) => setForm({ ...form, checkInTime: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                />
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Check-out Time *</label>
                <input
                  type="time"
                  required
                  value={form.checkOutTime}
                  onChange={(e) => setForm({ ...form, checkOutTime: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                />
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">GSTIN</label>
                <input
                  type="text"
                  value={form.hotelGstin}
                  onChange={(e) => setForm({ ...form, hotelGstin: e.target.value.toUpperCase() })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                  placeholder="Optional, auto-filled from profile if available"
                />
              </div>
              {isDharamshalaForm && (
                <div className="md:col-span-2 rounded-lg border border-brand-gold/25 bg-brand-gold/10 p-3 font-body text-xs text-muted-foreground">
                  Dharamshala flow: guest sends request, you accept or reject it, then choose whether the guest pays room contribution online now or at check-in. Any admin-configured platform fee is applied automatically.
                </div>
              )}
              <div className="md:col-span-2 rounded-lg border border-border bg-muted/30 p-3">
                <label className="flex items-start gap-3 font-body text-sm font-medium text-foreground">
                  <input
                    type="checkbox"
                    checked={form.showPrices}
                    onChange={(e) => setForm({ ...form, showPrices: e.target.checked })}
                    className="mt-1"
                  />
                  <span>
                    Show prices and online booking on this property
                    <span className="block text-xs font-normal text-muted-foreground mt-1">
                      Turn this off when bookings should happen only by call or WhatsApp.
                    </span>
                  </span>
                </label>
              </div>
              {!isDharamshalaForm && form.hotelGstin.trim() && (
                <div className="md:col-span-2 rounded-lg border border-border bg-muted/30 p-3">
                  <label className="flex items-center gap-2 font-body text-sm font-medium text-foreground">
                    <input
                      type="checkbox"
                      checked={form.taxEnabled}
                      onChange={(e) => setForm({ ...form, taxEnabled: e.target.checked })}
                    />
                    Take GST on this property
                  </label>
                  {form.taxEnabled && (
                    <div className="mt-3 grid gap-3 sm:grid-cols-2">
                      <label className={`rounded-lg border px-3 py-2 font-body text-xs ${form.gstMode === 'automatic' ? 'border-brand-gold bg-white' : 'border-border bg-background'}`}>
                        <input
                          type="radio"
                          name="gstMode"
                          value="automatic"
                          checked={form.gstMode === 'automatic'}
                          onChange={() => setForm({ ...form, gstMode: 'automatic' })}
                          className="mr-2"
                        />
                        Automatic: 5% up to Rs. 7,500, 18% above Rs. 7,500
                      </label>
                      <label className={`rounded-lg border px-3 py-2 font-body text-xs ${form.gstMode === 'manual' ? 'border-brand-gold bg-white' : 'border-border bg-background'}`}>
                        <input
                          type="radio"
                          name="gstMode"
                          value="manual"
                          checked={form.gstMode === 'manual'}
                          onChange={() => setForm({ ...form, gstMode: 'manual' })}
                          className="mr-2"
                        />
                        Manual GST percentage
                      </label>
                      {form.gstMode === 'manual' && (
                        <div>
                          <label className="font-body text-xs font-medium text-foreground mb-1.5 block">GST Percent</label>
                          <input
                            type="number"
                            min="0"
                            max="50"
                            value={form.taxPercent}
                            onChange={(e) => setForm({ ...form, taxPercent: e.target.value })}
                            className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                          />
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              <input
                id="hotelPetsAllowed"
                type="checkbox"
                checked={form.petsAllowed}
                onChange={(e) => setForm({ ...form, petsAllowed: e.target.checked })}
              />
              <label htmlFor="hotelPetsAllowed" className="font-body text-sm text-foreground">
                Pets Allowed (Hotel Level)
              </label>
            </div>

            <div>
              <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Amenities (comma separated)</label>
              <input
                type="text"
                value={form.amenities}
                onChange={(e) => setForm({ ...form, amenities: e.target.value })}
                className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                placeholder="WiFi, TV, Hot Water"
              />
            </div>

            <div>
              <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Description</label>
              <textarea
                rows={3}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50 resize-none"
              />
            </div>

            <PropertyTermsEditor
              value={form.propertyTerms}
              onChange={(propertyTerms) => setForm({ ...form, propertyTerms })}
            />

            <div>
              <label className="font-body text-sm font-medium text-foreground mb-2 block">Photos</label>
              <div className="flex flex-wrap gap-3 mb-3">
                {form.images.map((img, i) => (
                  <div key={i} className="relative w-24 h-24 rounded-lg overflow-hidden border border-border">
                    <img src={img} alt="" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => removeImage(i)}
                      className="absolute top-1 right-1 w-5 h-5 rounded-full bg-destructive text-primary-foreground flex items-center justify-center"
                    >
                      <X size={10} />
                    </button>
                  </div>
                ))}
                <label className="w-24 h-24 rounded-lg border-2 border-dashed border-border flex flex-col items-center justify-center cursor-pointer hover:bg-muted transition-colors">
                  <ImageIcon size={20} className="text-muted-foreground mb-1" />
                  <span className="font-body text-[10px] text-muted-foreground">Upload</span>
                  <input type="file" accept="image/*" multiple onChange={handleImageUpload} className="hidden" />
                </label>
              </div>
              <p className="font-body text-[11px] text-muted-foreground">
                First photo becomes the main photo.
              </p>
            </div>

            <div className="flex gap-3">
              <button type="submit" className="btn-crimson px-6 py-2.5 rounded-xl text-sm">
                {editingId ? 'Resubmit' : 'Submit'}
              </button>
              <button
                type="button"
                onClick={resetForm}
                className="px-6 py-2.5 rounded-xl text-sm border border-border font-body hover:bg-muted transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {isLoading ? (
        <div className="bg-card rounded-xl border border-border p-12 text-center">
          <p className="font-body text-sm text-muted-foreground">Loading…</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-card rounded-xl border border-border p-12 text-center">
          <p className="font-heading text-xl text-foreground mb-2">No listing submissions</p>
          <p className="font-body text-sm text-muted-foreground">Submit your first hotel or dharamshala to get started.</p>
        </div>
      ) : (
        <>
        <div className="bg-card rounded-xl border border-border overflow-hidden overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="text-left px-4 py-3 font-body text-xs font-medium text-muted-foreground">Name</th>
                <th className="text-left px-4 py-3 font-body text-xs font-medium text-muted-foreground hidden sm:table-cell">Type</th>
                <th className="text-left px-4 py-3 font-body text-xs font-medium text-muted-foreground">Location</th>
                <th className="text-left px-4 py-3 font-body text-xs font-medium text-muted-foreground">Status</th>
                <th className="text-left px-4 py-3 font-body text-xs font-medium text-muted-foreground hidden md:table-cell">Admin</th>
                <th className="text-right px-4 py-3 font-body text-xs font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {pageItems.map((h) => (
                <tr key={h._id} className="border-b border-border last:border-0 hover:bg-muted/30">
                  <td className="px-4 py-3 font-body text-sm font-medium text-foreground">{h.name}</td>
                  <td className="px-4 py-3 font-body text-sm text-muted-foreground hidden sm:table-cell capitalize">{h.propertyType || 'hotel'}</td>
                  <td className="px-4 py-3 font-body text-sm text-muted-foreground">{h.location}</td>
                  <td className="px-4 py-3">
                    <span className={`font-body text-xs px-2 py-1 rounded-full ${statusBadge(h.approvalStatus)}`}>
                      {h.approvalStatus}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-body text-xs text-muted-foreground hidden md:table-cell">
                    {h.adminRemarks || '-'}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handlePrices(h)}
                        className="p-1.5 rounded hover:bg-brand-gold/10 transition-colors text-muted-foreground hover:text-brand-gold"
                        title="Add or edit prices"
                      >
                        <IndianRupee size={14} />
                      </button>
                      <button
                        onClick={() => handleEdit(h)}
                        className="p-1.5 rounded hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                      >
                        <Pencil size={14} />
                      </button>
                      {deleteConfirm === h._id ? (
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleDelete(h._id)}
                            className="text-xs font-body text-destructive hover:underline"
                          >
                            Delete
                          </button>
                          <button
                            onClick={() => setDeleteConfirm(null)}
                            className="text-xs font-body text-muted-foreground hover:underline"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setDeleteConfirm(h._id)}
                          className="p-1.5 rounded hover:bg-destructive/10 transition-colors text-muted-foreground hover:text-destructive"
                        >
                          <Trash2 size={14} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <RecordPagination page={page} total={filtered.length} onPageChange={setPage} />
        </>
      )}
    </div>
  );
};

export default PartnerAddHotel;
