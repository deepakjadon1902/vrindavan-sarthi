import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Pencil, Trash2, Search, X, Upload, Image as ImageIcon, Building2, IndianRupee } from 'lucide-react';
import { toast } from 'sonner';
import { api, withAuth } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';
import { publishAppEvent } from '@/lib/broadcast';
import { getApiErrorMessage } from '@/lib/apiError';
import { BRAJ_LANDMARK_PLACE_NAMES, OTHER_LANDMARK_OPTION, getLandmarkOptionsForPlace, getLandmarkPlaceForListing } from '@/lib/landmarks';
import { PropertyTermsEditor, hasPropertyTermsText, normalizePropertyTerms, type PropertyTermsValue } from '@/components/shared/PropertyTerms';
import { getPropertyTypeLabel, isDharamshalaType, propertyTypeOptions, type StayPropertyType } from '@/lib/propertyTypes';
import RecordPagination, { useRecordPagination } from '@/components/shared/RecordPagination';

interface Hotel {
  _id: string;
  name: string;
  propertyType?: StayPropertyType;
  location: string;
  rating: number;
  image?: string;
  images?: string[];
  description?: string;
  amenities?: string[];
  googleMapLink?: string;
  nearestTemple?: string;
  checkInTime?: string;
  checkOutTime?: string;
  hotelGstin?: string;
  showPrices?: boolean;
  dharamshalaPaymentMode?: 'pay_at_dharamshala' | 'full_online' | 'request_only';
  dharamshalaPlatformFeeEnabled?: boolean;
  dharamshalaServiceFee?: number;
  dharamshalaResponseTimeoutMinutes?: number;
  taxEnabled?: boolean;
  taxPercent?: number;
  platform_commission_percentage?: number;
  propertyTerms?: PropertyTermsValue;
  status: 'active' | 'inactive';
  approvalStatus?: 'pending' | 'approved' | 'rejected';
  partnerName?: string;
  createdAt?: string;
}

const ManageHotels = () => {
  const navigate = useNavigate();
  const token = useAuthStore((s) => s.token);
  const [items, setItems] = useState<Hotel[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');

  const [form, setForm] = useState({
    name: '',
    propertyType: 'hotel' as Hotel['propertyType'],
    place: '',
    location: '',
    rating: '',
    description: '',
    amenities: '',
    googleMapLink: '',
    nearestTemple: '',
    checkInTime: '12:00',
    checkOutTime: '11:00',
    hotelGstin: '',
    status: 'active' as Hotel['status'],
    image: '',
    taxEnabled: false,
    taxPercent: '12',
    platform_commission_percentage: '10',
    showPrices: true,
    dharamshalaPaymentMode: 'pay_at_dharamshala' as const,
    dharamshalaPlatformFeeEnabled: true,
    dharamshalaServiceFee: '79',
    dharamshalaResponseTimeoutMinutes: '30',
    propertyTerms: normalizePropertyTerms(),
  });

  const load = async () => {
    if (!token) return;
    try {
      setIsLoading(true);
      const res = await api.get('/hotels/all', withAuth(token));
      setItems(Array.isArray(res.data?.data) ? res.data.data : []);
    } catch (err: unknown) {
      toast.error(getApiErrorMessage(err, 'Failed to load hotels'));
      setItems([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  const resetForm = () => {
    setForm({
      name: '',
      propertyType: 'hotel',
      place: '',
      location: '',
      rating: '',
      description: '',
      amenities: '',
      googleMapLink: '',
      nearestTemple: '',
      checkInTime: '12:00',
      checkOutTime: '11:00',
      hotelGstin: '',
      status: 'active',
      image: '',
      taxEnabled: false,
      taxPercent: '12',
      platform_commission_percentage: '10',
      showPrices: true,
      dharamshalaPaymentMode: 'pay_at_dharamshala',
      dharamshalaPlatformFeeEnabled: true,
      dharamshalaServiceFee: '79',
      dharamshalaResponseTimeoutMinutes: '30',
      propertyTerms: normalizePropertyTerms(),
    });
    setImagePreview('');
    setEditingId(null);
    setShowForm(false);
  };

  const reusablePropertyTerms = () => {
    const saved = items.find((item) => hasPropertyTermsText(item.propertyTerms))?.propertyTerms;
    return normalizePropertyTerms(saved);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      setImagePreview(result);
      setForm((prev) => ({ ...prev, image: result }));
    };
    reader.readAsDataURL(file);
  };

  const handleEdit = (hotel: Hotel) => {
    setForm({
      name: hotel.name || '',
      propertyType: hotel.propertyType || 'hotel',
      place: getLandmarkPlaceForListing(hotel.nearestTemple, hotel.location),
      location: hotel.location || '',
      rating: String(hotel.rating ?? ''),
      description: hotel.description || '',
      amenities: (hotel.amenities || []).join(', '),
      googleMapLink: hotel.googleMapLink || '',
      nearestTemple: hotel.nearestTemple || '',
      checkInTime: hotel.checkInTime || '12:00',
      checkOutTime: hotel.checkOutTime || '11:00',
      hotelGstin: hotel.hotelGstin || '',
      status: hotel.status || 'active',
      image: hotel.image || '',
      taxEnabled: Boolean(hotel.taxEnabled),
      taxPercent: String(hotel.taxPercent ?? 12),
      platform_commission_percentage: String(hotel.platform_commission_percentage ?? 10),
      showPrices: hotel.showPrices !== false,
      dharamshalaPaymentMode: hotel.dharamshalaPaymentMode || 'pay_at_dharamshala',
      dharamshalaPlatformFeeEnabled: hotel.dharamshalaPlatformFeeEnabled !== false,
      dharamshalaServiceFee: String(hotel.dharamshalaServiceFee ?? 79),
      dharamshalaResponseTimeoutMinutes: String(hotel.dharamshalaResponseTimeoutMinutes ?? 30),
      propertyTerms: normalizePropertyTerms(hotel.propertyTerms),
    });
    setImagePreview(hotel.image || '');
    setEditingId(hotel._id);
    setShowForm(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    const nearestTemple = form.nearestTemple === OTHER_LANDMARK_OPTION ? '' : form.nearestTemple.trim();
    if (!nearestTemple) {
      toast.error('Please select or enter nearest temple / landmark');
      return;
    }

    const payload: Partial<Hotel> & {
      amenities: string[];
      partnerSubmitted?: boolean;
    } = {
      name: form.name,
      propertyType: form.propertyType,
      location: form.location,
      rating: Number(form.rating || 0),
      image: form.image || '/placeholder.svg',
      description: form.description,
      googleMapLink: form.googleMapLink.trim() || form.location.trim(),
      nearestTemple,
      checkInTime: form.checkInTime || '12:00',
      checkOutTime: form.checkOutTime || '11:00',
      hotelGstin: form.hotelGstin.trim(),
      amenities: form.amenities
        .split(',')
        .map((a) => a.trim())
        .filter(Boolean),
      status: form.status,
      approvalStatus: 'approved',
      partnerSubmitted: false,
      taxEnabled: isDharamshalaType(form.propertyType) ? false : form.taxEnabled,
      taxPercent: isDharamshalaType(form.propertyType) ? 0 : Number(form.taxPercent || 12),
      platform_commission_percentage: isDharamshalaType(form.propertyType) ? 10 : Number(form.platform_commission_percentage || 0),
      showPrices: Boolean(form.showPrices),
      dharamshalaPaymentMode: form.dharamshalaPaymentMode,
      dharamshalaPlatformFeeEnabled: Boolean(form.dharamshalaPlatformFeeEnabled),
      dharamshalaServiceFee: Number(form.dharamshalaServiceFee || 0),
      dharamshalaResponseTimeoutMinutes: Number(form.dharamshalaResponseTimeoutMinutes || 30),
      propertyTerms: form.propertyTerms,
    };
    if (editingId && payload.image === '/placeholder.svg') delete payload.image;

    try {
      if (editingId) {
        const res = await api.put(`/hotels/${editingId}`, payload, withAuth(token));
        const updated = res.data?.data as Hotel;
        setItems((prev) => prev.map((h) => (h._id === editingId ? updated : h)));
        toast.success('Hotel updated');
      } else {
        const res = await api.post('/hotels', payload, withAuth(token));
        const created = res.data?.data as Hotel;
        setItems((prev) => [created, ...prev]);
        toast.success('Hotel added');
      }
      publishAppEvent('listing:changed');
      resetForm();
    } catch (err: unknown) {
      toast.error(getApiErrorMessage(err, editingId ? 'Update failed' : 'Create failed'));
    }
  };

  const landmarkOptionsForPlace = getLandmarkOptionsForPlace(form.place);
  const nearestTempleSelectValue = form.nearestTemple && landmarkOptionsForPlace.includes(form.nearestTemple)
    ? form.nearestTemple
    : form.nearestTemple
      ? OTHER_LANDMARK_OPTION
      : '';

  const handlePlaceChange = (place: string) => {
    const shouldUsePlaceAsLocation = !form.location.trim() || form.location.trim() === form.place;
    setForm({
      ...form,
      place,
      location: place && place !== OTHER_LANDMARK_OPTION && shouldUsePlaceAsLocation ? place : form.location,
      nearestTemple: '',
    });
  };

  const handleDelete = async (id: string) => {
    if (!token) return;
    try {
      await api.delete(`/hotels/${id}`, withAuth(token));
      setItems((prev) => prev.filter((h) => h._id !== id));
      toast.success('Hotel deleted');
      publishAppEvent('listing:changed');
    } catch {
      toast.error('Delete failed');
    } finally {
      setDeleteConfirm(null);
    }
  };

  const handlePrices = (hotel: Hotel) => {
    navigate(`/admin/inventory?hotelId=${encodeURIComponent(hotel._id)}`);
  };

  const filtered = useMemo(
    () =>
      items.filter(
        (h) =>
          h.name.toLowerCase().includes(search.toLowerCase()) ||
          h.location.toLowerCase().includes(search.toLowerCase())
      ).sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()),
    [items, search]
  );
  const { page, setPage, pageItems } = useRecordPagination(filtered, [search]);
  const actionButtonClass = 'inline-flex h-10 w-10 items-center justify-center rounded-lg border border-border bg-white text-muted-foreground shadow-sm transition-colors hover:border-brand-gold/50 hover:bg-brand-gold/10 hover:text-brand-crimson';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search hotels..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 rounded-lg border border-border bg-card font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
          />
        </div>
        <button
          onClick={() => {
            resetForm();
            setForm((prev) => ({ ...prev, propertyTerms: reusablePropertyTerms() }));
            setShowForm(true);
          }}
          className="btn-crimson px-5 py-2.5 rounded-lg text-sm flex items-center gap-2"
        >
          <Plus size={16} /> Add Hotel
        </button>
      </div>

      {showForm && (
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-heading text-lg font-semibold">{editingId ? 'Edit Hotel' : 'Add New Hotel'}</h3>
            <button onClick={resetForm} className="text-muted-foreground hover:text-foreground">
              <X size={20} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Hotel Image</label>
              <div className="flex items-start gap-4">
                {imagePreview ? (
                  <div className="relative w-32 h-24 rounded-lg overflow-hidden border border-border">
                    <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => {
                        setImagePreview('');
                        setForm((prev) => ({ ...prev, image: '' }));
                      }}
                      className="absolute top-1 right-1 bg-foreground/80 text-primary-foreground rounded-full p-1"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ) : (
                  <label className="w-32 h-24 border-2 border-dashed border-border rounded-lg flex flex-col items-center justify-center cursor-pointer hover:bg-muted transition-colors">
                    <Upload size={18} className="text-muted-foreground mb-1" />
                    <span className="font-body text-xs text-muted-foreground">Upload</span>
                    <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                  </label>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Hotel Name</label>
                <input
                  type="text"
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                  placeholder="Krishna Palace"
                />
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Listing Type</label>
                <select
                  value={form.propertyType}
                  onChange={(e) => setForm({
                    ...form,
                    propertyType: e.target.value as Hotel['propertyType'],
                    taxEnabled: isDharamshalaType(e.target.value) ? false : form.taxEnabled,
                    platform_commission_percentage: isDharamshalaType(e.target.value) ? '10' : form.platform_commission_percentage,
                  })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                >
                  {propertyTypeOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
                </select>
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Place</label>
                <select
                  required
                  value={form.place}
                  onChange={(e) => handlePlaceChange(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                >
                  <option value="">Select place</option>
                  {BRAJ_LANDMARK_PLACE_NAMES.map((place) => <option key={place} value={place}>{place}</option>)}
                  <option value={OTHER_LANDMARK_OPTION}>{OTHER_LANDMARK_OPTION}</option>
                </select>
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Location / Full Address</label>
                <input
                  type="text"
                  required
                  value={form.location}
                  onChange={(e) => setForm({ ...form, location: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                  placeholder="Area, road, or complete address"
                />
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Rating</label>
                <input
                  type="number"
                  min="0"
                  max="5"
                  step="0.1"
                  value={form.rating}
                  onChange={(e) => setForm({ ...form, rating: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                  placeholder="4.5"
                />
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Platform Commission (%)</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="0.01"
                  required
                  disabled={isDharamshalaType(form.propertyType)}
                  value={form.platform_commission_percentage}
                  onChange={(e) => setForm({ ...form, platform_commission_percentage: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                  placeholder="10"
                />
                <p className="font-body text-xs text-muted-foreground mt-1">
                  {isDharamshalaType(form.propertyType) ? 'Dharamshala bookings use the platform fee configured below.' : 'Set the platform commission for this listing.'}
                </p>
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Map Location / Google Link</label>
                <input
                  type="text"
                  value={form.googleMapLink}
                  onChange={(e) => setForm({ ...form, googleMapLink: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                  placeholder="Leave blank to use the hotel location automatically"
                />
                <p className="font-body text-xs text-muted-foreground mt-1">If blank, the public map uses the Location field.</p>
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Nearby Landmark / Temple</label>
                <select
                  required
                  value={nearestTempleSelectValue}
                  onChange={(e) => setForm({ ...form, nearestTemple: e.target.value === OTHER_LANDMARK_OPTION ? OTHER_LANDMARK_OPTION : e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                >
                  <option value="">{form.place ? 'Select nearby landmark / temple' : 'Select place first'}</option>
                  {landmarkOptionsForPlace.map((name) => <option key={name} value={name}>{name}</option>)}
                  <option value={OTHER_LANDMARK_OPTION}>{OTHER_LANDMARK_OPTION}</option>
                </select>
                {nearestTempleSelectValue === OTHER_LANDMARK_OPTION && (
                  <input
                    type="text"
                    required
                    value={form.nearestTemple === OTHER_LANDMARK_OPTION ? '' : form.nearestTemple}
                    onChange={(e) => setForm({ ...form, nearestTemple: e.target.value.trimStart() || OTHER_LANDMARK_OPTION })}
                    className="mt-2 w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                    placeholder="Enter landmark manually"
                  />
                )}
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Check-in Time</label>
                <input
                  type="time"
                  required
                  value={form.checkInTime}
                  onChange={(e) => setForm({ ...form, checkInTime: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                />
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Check-out Time</label>
                <input
                  type="time"
                  required
                  value={form.checkOutTime}
                  onChange={(e) => setForm({ ...form, checkOutTime: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                />
              </div>
              <div>
                <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Hotel GSTIN</label>
                <input
                  type="text"
                  value={form.hotelGstin}
                  onChange={(e) => setForm({ ...form, hotelGstin: e.target.value.toUpperCase() })}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                  placeholder="Optional partner GSTIN"
                />
              </div>
            </div>

            <div className="flex items-center gap-4">
              <label className="font-body text-sm font-medium text-foreground">Status</label>
              <select
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value as Hotel['status'] })}
                className="px-3 py-1.5 rounded-lg border border-border bg-background font-body text-sm"
              >
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>

            <div className="rounded-lg border border-border bg-muted/30 p-4">
              <label className="flex items-start gap-3 font-body text-sm text-foreground">
                <input
                  type="checkbox"
                  checked={form.showPrices}
                  onChange={(e) => setForm({ ...form, showPrices: e.target.checked })}
                  className="mt-1"
                />
                <span>
                  Show prices and online booking on this property
                  <span className="block text-xs text-muted-foreground mt-1">
                    Turn this off when guests should book by call or WhatsApp only.
                  </span>
                </span>
              </label>
            </div>

            {isDharamshalaType(form.propertyType) && (
              <div className="rounded-lg border border-brand-gold/25 bg-brand-gold/10 p-4 font-body text-sm text-muted-foreground">
                Dharamshala flow: guest sends request, partner accepts or rejects, then partner chooses whether the guest pays room contribution online now or at check-in.
                <label className="mt-3 flex items-start gap-3 text-foreground">
                  <input
                    type="checkbox"
                    checked={Boolean(form.dharamshalaPlatformFeeEnabled)}
                    onChange={(e) => setForm({ ...form, dharamshalaPlatformFeeEnabled: e.target.checked })}
                    className="mt-1"
                  />
                  <span>
                    Apply platform fee on this Dharamshala
                    <span className="block text-xs font-normal text-muted-foreground mt-1">If disabled, bookings can confirm without a platform fee when partner chooses pay-at-check-in.</span>
                  </span>
                </label>
                {form.dharamshalaPlatformFeeEnabled && (
                  <label className="mt-3 block">
                    <span className="block text-xs font-medium text-foreground">Platform fee amount</span>
                    <input
                      type="number"
                      min="0"
                      value={form.dharamshalaServiceFee}
                      onChange={(e) => setForm({ ...form, dharamshalaServiceFee: e.target.value })}
                      className="mt-1 w-40 px-3 py-2 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                    />
                  </label>
                )}
              </div>
            )}

            <div className="rounded-lg border border-border bg-muted/30 p-4">
              <label className="flex items-start gap-3 font-body text-sm text-foreground">
                <input
                  type="checkbox"
                  checked={form.taxEnabled}
                  disabled={isDharamshalaType(form.propertyType)}
                  onChange={(e) => setForm({ ...form, taxEnabled: e.target.checked })}
                  className="mt-1"
                />
                <span>
                  Apply GST to this property
                  <span className="block text-xs text-muted-foreground mt-1">
                    {isDharamshalaType(form.propertyType) ? 'GST and hotel tax controls do not apply to Dharamshala request bookings.' : 'GST settings apply to hotels, home stays, and guest houses.'}
                  </span>
                </span>
              </label>
              {form.taxEnabled && (
                <input
                  type="number"
                  min="0"
                  max="50"
                  step="0.01"
                  value={form.taxPercent}
                  onChange={(e) => setForm({ ...form, taxPercent: e.target.value })}
                  className="mt-3 w-36 px-3 py-2 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                />
              )}
            </div>

            <div>
              <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Amenities (comma separated)</label>
              <input
                type="text"
                value={form.amenities}
                onChange={(e) => setForm({ ...form, amenities: e.target.value })}
                className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                placeholder="WiFi, TV, Hot Water"
              />
            </div>

            <div>
              <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Description</label>
              <textarea
                rows={3}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="w-full px-4 py-2.5 rounded-lg border border-border bg-background font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50 resize-none"
                placeholder="Hotel details..."
              />
            </div>

            <PropertyTermsEditor
              value={form.propertyTerms}
              onChange={(propertyTerms) => setForm({ ...form, propertyTerms })}
            />

            <div className="flex gap-3 pt-2">
              <button type="submit" className="btn-crimson px-6 py-2.5 rounded-lg text-sm">
                {editingId ? 'Update' : 'Add Hotel'}
              </button>
              <button
                type="button"
                onClick={resetForm}
                className="px-6 py-2.5 rounded-lg text-sm border border-border font-body hover:bg-muted transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {isLoading ? (
        <div className="bg-card rounded-xl border border-border p-12 text-center">
          <p className="font-body text-muted-foreground">Loading hotels…</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-card rounded-xl border border-border p-12 text-center">
          <Building2 size={48} className="mx-auto mb-4 text-muted-foreground/30" />
          <p className="font-body text-muted-foreground">No hotels added yet</p>
          <p className="font-body text-xs text-muted-foreground/60 mt-1">Click "Add Hotel" to get started</p>
        </div>
      ) : (
        <>
        <div className="bg-card rounded-xl border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/50">
                  <th className="text-left px-4 py-3 font-body text-xs font-medium text-muted-foreground">Image</th>
                  <th className="text-left px-4 py-3 font-body text-xs font-medium text-muted-foreground">Name</th>
                  <th className="text-left px-4 py-3 font-body text-xs font-medium text-muted-foreground hidden sm:table-cell">Location</th>
                  <th className="text-left px-4 py-3 font-body text-xs font-medium text-muted-foreground hidden md:table-cell">Rating</th>
                  <th className="text-left px-4 py-3 font-body text-xs font-medium text-muted-foreground hidden md:table-cell">Status</th>
                  <th className="text-left px-4 py-3 font-body text-xs font-medium text-muted-foreground hidden lg:table-cell">GST</th>
                  <th className="text-left px-4 py-3 font-body text-xs font-medium text-muted-foreground hidden lg:table-cell">Commission</th>
                  <th className="text-left px-4 py-3 font-body text-xs font-medium text-muted-foreground hidden lg:table-cell">Listed By</th>
                  <th className="min-w-[150px] text-right px-4 py-3 font-body text-xs font-medium text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody>
                {pageItems.map((hotel) => (
                  <tr key={hotel._id} className="border-b border-border last:border-0 hover:bg-muted/30">
                    <td className="px-4 py-3">
                      <div className="w-12 h-9 rounded overflow-hidden bg-muted">
                        {hotel.image && hotel.image !== '/placeholder.svg' ? (
                          <img src={hotel.image} alt={hotel.name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <ImageIcon size={14} className="text-muted-foreground" />
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3 font-body text-sm font-medium text-foreground">{hotel.name}</td>
                    <td className="px-4 py-3 font-body text-sm text-muted-foreground hidden sm:table-cell">{hotel.location}</td>
                    <td className="px-4 py-3 font-body text-sm text-foreground hidden md:table-cell">⭐ {hotel.rating}</td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <span
                        className={`font-body text-xs px-2 py-1 rounded-full ${
                          hotel.status === 'active' ? 'bg-brand-green/10 text-brand-green' : 'bg-muted text-muted-foreground'
                        }`}
                      >
                        {hotel.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-body text-xs text-muted-foreground hidden lg:table-cell">
                      {hotel.taxEnabled ? `${hotel.taxPercent ?? 12}%` : 'Free'}
                    </td>
                    <td className="px-4 py-3 font-body text-xs text-muted-foreground hidden lg:table-cell">
                      {hotel.platform_commission_percentage ?? 0}%
                    </td>
                    <td className="px-4 py-3 font-body text-xs text-muted-foreground hidden lg:table-cell">
                      <span className="block font-medium text-foreground">{getPropertyTypeLabel(hotel.propertyType)}</span>
                      {hotel.partnerName || 'Admin'}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handlePrices(hotel)}
                          className={actionButtonClass}
                          title="Add or edit prices"
                          aria-label={`Add or edit prices for ${hotel.name}`}
                        >
                          <IndianRupee size={20} strokeWidth={2.4} />
                        </button>
                        <button
                          onClick={() => handleEdit(hotel)}
                          className={actionButtonClass}
                          title="Edit hotel"
                          aria-label={`Edit ${hotel.name}`}
                        >
                          <Pencil size={20} strokeWidth={2.4} />
                        </button>
                        {deleteConfirm === hotel._id ? (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => handleDelete(hotel._id)}
                              className="text-xs font-body text-destructive hover:underline"
                            >
                              Delete
                            </button>
                            <button
                              onClick={() => setDeleteConfirm(null)}
                              className="text-xs font-body text-muted-foreground hover:underline"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setDeleteConfirm(hotel._id)}
                            className={`${actionButtonClass} hover:border-destructive/30 hover:bg-destructive/10 hover:text-destructive`}
                            title="Delete hotel"
                            aria-label={`Delete ${hotel.name}`}
                          >
                            <Trash2 size={20} strokeWidth={2.4} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <RecordPagination page={page} total={filtered.length} onPageChange={setPage} />
        </>
      )}
    </div>
  );
};

export default ManageHotels;
