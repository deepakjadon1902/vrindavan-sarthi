import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { useAuthStore } from '@/store/authStore';
import { useSettingsStore } from '@/store/settingsStore';
import { toast } from 'sonner';
import templeImg from '@/assets/images/temple-about.jpg';
import PasswordInput from '@/components/shared/PasswordInput';
import { startGoogleSignIn } from '@/lib/oauth';

type StaffLoginRole = 'admin' | 'partner';

const hasNativeApkMarker = () => {
  if (typeof window === 'undefined') return false;
  try {
    return window.sessionStorage.getItem('vrs_native_apk') === '1' || window.localStorage.getItem('vrs_native_apk') === '1';
  } catch {
    return false;
  }
};

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login, isLoading, logout, isAuthenticated, user } = useAuthStore();
  const settings = useSettingsStore((s) => s.settings);
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const roleParam = searchParams.get('role');
  const isStaffLogin = searchParams.get('staff') === '1';
  const [isNativeApk, setIsNativeApk] = useState(() => searchParams.get('vrsApk') === '1' || hasNativeApkMarker());
  const [loginRole, setLoginRole] = useState<StaffLoginRole>(roleParam === 'admin' ? 'admin' : 'partner');
  const isPartnerOnlyStaffLogin = isStaffLogin && (roleParam === 'partner' || isNativeApk);

  useEffect(() => {
    if (searchParams.get('vrsApk') !== '1') return;
    setIsNativeApk(true);
    try {
      window.sessionStorage.setItem('vrs_native_apk', '1');
      window.localStorage.setItem('vrs_native_apk', '1');
    } catch {
      // ignore storage restrictions
    }
  }, [searchParams]);

  useEffect(() => {
    if (!isStaffLogin) return;
    if (isPartnerOnlyStaffLogin) {
      setLoginRole('partner');
      return;
    }
    if (roleParam === 'admin' || roleParam === 'partner') setLoginRole(roleParam);
  }, [isPartnerOnlyStaffLogin, isStaffLogin, roleParam]);

  useEffect(() => {
    if (!isAuthenticated || !user) return;
    if (isStaffLogin && user.role === 'admin') {
      navigate('/admin', { replace: true });
      return;
    }
    if (isStaffLogin && user.role === 'partner') {
      navigate('/partner', { replace: true });
      return;
    }
    if (!isStaffLogin && user.role === 'user') {
      navigate('/', { replace: true });
    }
  }, [isAuthenticated, isStaffLogin, navigate, user]);

  useEffect(() => {
    const error = searchParams.get('error');
    if (!error) return;
    const message =
      error === 'google_oauth_not_configured'
        ? 'Google sign-in is not configured. Please set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in backend/.env.'
        : `Login error: ${error}`;
    toast.error(message);
    setSearchParams({}, { replace: true });
  }, [searchParams, setSearchParams]);

  const handleGoogle = () => {
    startGoogleSignIn('/');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const result = await login({ email, password });
    if (result.success) {
      const user = useAuthStore.getState().user;
      if (isStaffLogin && loginRole === 'partner' && user?.role !== 'partner') {
        logout();
        toast.error('Please use a partner account to access Partner Login.');
        return;
      }
      if (isStaffLogin && loginRole === 'admin' && user?.role !== 'admin') {
        logout();
        toast.error('Please use an admin account to access Admin Login.');
        return;
      }
      if (user) {
        const displayName =
          user.role === 'partner'
            ? (user.businessName || user.name || 'Partner')
            : (user.name || (user.role === 'admin' ? 'Admin' : 'User'));
        const message =
          user.role === 'admin'
            ? `Welcome back, Admin${displayName && displayName !== 'Admin' ? ` ${displayName}` : ''}!`
            : `Welcome back, ${displayName}!`;
        toast.success(message);
      } else {
        toast.success('Welcome back!');
      }
      if (user?.role === 'partner') {
        navigate('/partner', { replace: true });
      } else if (user?.role === 'admin') {
        navigate('/admin', { replace: true });
      } else {
        navigate('/', { replace: true });
      }
    } else {
      toast.error(result.error || 'Login failed');
    }
  };

  return (
    <div className="min-h-screen flex">
      <div className="hidden lg:flex lg:w-1/2 relative">
        <img src={templeImg} alt="Vrindavan Temple" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-white/40 flex items-center justify-center">
          <div className="text-center px-8 bg-white/70 backdrop-blur-sm rounded-2xl py-10 border border-border">
            <span className="text-4xl mb-4 block"> </span>
            <h2 className="font-brand text-3xl text-brand-gold mb-2">{settings.siteName}</h2>
            <p className="font-heading italic text-xl text-foreground">{settings.motto}</p>
          </div>
        </div>
      </div>

      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          <div className="text-center mb-8 lg:hidden">
            <span className="text-3xl"> </span>
            <h2 className="font-brand text-2xl text-brand-gold mt-2">{settings.siteName}</h2>
          </div>

          <h1 className="font-heading text-3xl font-semibold text-foreground mb-2">
            {isStaffLogin ? (loginRole === 'admin' ? 'Admin Login' : 'Partner Login') : 'Welcome Back'}
          </h1>
          <p className="font-body text-muted-foreground mb-8">
            {isStaffLogin
              ? loginRole === 'admin'
                ? 'Sign in to manage the admin panel'
                : 'Sign in to manage your listings and bookings'
              : 'Sign in to continue your booking journey'}
          </p>

          {isStaffLogin && !isPartnerOnlyStaffLogin ? (
          <div className="mb-6 grid grid-cols-2 gap-2 rounded-xl border border-border bg-muted/30 p-1">
            {([
              ['partner', 'Partner'],
              ['admin', 'Admin'],
            ] as const).map(([role, label]) => (
              <button
                key={role}
                type="button"
                onClick={() => {
                  setLoginRole(role);
                  setSearchParams({ staff: '1', role }, { replace: true });
                }}
                className={`min-h-11 rounded-lg font-body text-sm font-bold transition-colors ${
                  loginRole === role
                    ? 'bg-brand-crimson text-primary-foreground shadow-sm'
                    : 'text-muted-foreground hover:bg-background hover:text-foreground'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
          ) : !isStaffLogin ? (
            <>
              <button
                onClick={handleGoogle}
                className="w-full flex items-center justify-center gap-3 border border-border rounded-xl py-3 font-body text-sm hover:bg-muted transition-colors mb-6"
              >
                <svg width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" /><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" /><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" /><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" /></svg>
                Continue with Google
              </button>

              <div className="flex items-center gap-4 mb-6">
                <div className="flex-1 h-px bg-border" />
                <span className="font-body text-xs text-muted-foreground">OR</span>
                <div className="flex-1 h-px bg-border" />
              </div>
            </>
          ) : (
            <div className="mb-6 rounded-xl border border-brand-gold/30 bg-brand-gold/10 px-4 py-3">
              <p className="font-body text-sm font-semibold text-foreground">Partner access</p>
              <p className="mt-1 font-body text-xs text-muted-foreground">Sign in with your approved partner account.</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Email</label>
              <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="w-full px-4 py-3 rounded-lg border border-border bg-card font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50" placeholder="your@email.com" />
            </div>
            <div>
              <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Password</label>
              <PasswordInput
                required
                value={password}
                onChange={setPassword}
                autoComplete="current-password"
                className="w-full px-4 py-3 rounded-lg border border-border bg-card font-body text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50"
                placeholder="............."
              />
            </div>
            <div className="text-right">
              <Link to="/forgot-password" className="font-body text-xs text-brand-gold hover:underline">Forgot Password?</Link>
            </div>
            <button type="submit" disabled={isLoading} className="btn-crimson w-full py-3.5 rounded-xl text-sm disabled:opacity-50">
              {isLoading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          <p className="font-body text-sm text-muted-foreground text-center mt-6">
            {isStaffLogin ? (loginRole === 'partner' ? 'New partner?' : 'Need a partner account?') : `New to ${settings.siteName}?`}{' '}
            <Link to={isStaffLogin ? `/register?role=partner${isNativeApk ? '&vrsApk=1' : ''}` : '/register'} className="text-brand-gold font-semibold hover:underline">
              {isStaffLogin ? 'Register as Partner' : 'Register'}
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
