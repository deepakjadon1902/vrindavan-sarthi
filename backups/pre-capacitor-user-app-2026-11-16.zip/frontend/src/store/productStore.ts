import { create } from 'zustand';
import { api, resolveBackendAssetUrl, withAuth } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';
import axios from 'axios';
import { publishAppEvent } from '@/lib/broadcast';

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  images: string[];
  inStock: boolean;
  createdAt: string;
}

export interface Order {
  id: string; // Mongo _id
  orderId: string; // human-friendly code like ORD-...
  trackingId?: string; // 5 digit tracking code
  productId: string;
  productName: string;
  productImage: string;
  productPrice: number;
  quantity: number;
  subtotalAmount?: number;
  shippingFee?: number;
  totalAmount: number;
  userId: string;
  userName: string;
  userEmail: string;
  userPhone: string;
  shippingAddress: string;
  orderNotes?: string;
  courierName?: string;
  awbNumber?: string;
  trackingUrl?: string;
  trackingNotes?: string;
  shippedAt?: string;
  deliveredAt?: string;
  statusHistory?: Array<{
    status: Order['orderStatus'];
    note?: string;
    updatedByName?: string;
    createdAt?: string;
  }>;
  paymentStatus: 'pending' | 'paid' | 'failed';
  orderStatus: 'pending' | 'processing' | 'confirmed' | 'packed' | 'shipped' | 'delivered' | 'cancelled';
  upiTransactionId?: string;
  invoiceSentAt?: string;
  cancellationReason?: string;
  cancelledByRole?: 'user' | 'admin';
  cancelledAt?: string;
  cancellationDetails?: string;
  cancellationDeductionPercent?: number;
  cancellationDeductionAmount?: number;
  refundableAmount?: number;
  createdAt: string;
  updatedAt?: string;
}

const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null;

const getString = (obj: Record<string, unknown>, key: string) => (typeof obj[key] === 'string' ? obj[key] : '');
const getNumber = (obj: Record<string, unknown>, key: string) => (typeof obj[key] === 'number' ? obj[key] : Number(obj[key] || 0));
const getBoolean = (obj: Record<string, unknown>, key: string) => (typeof obj[key] === 'boolean' ? obj[key] : Boolean(obj[key]));
const getStringArray = (obj: Record<string, unknown>, key: string) => {
  const v = obj[key];
  if (!Array.isArray(v)) return [];
  return v.filter((x): x is string => typeof x === 'string');
};
const normalizeStatusHistory = (obj: Record<string, unknown>): Order['statusHistory'] => {
  const value = obj.statusHistory;
  if (!Array.isArray(value)) return [];
  return value.filter(isRecord).map((item) => {
    const raw = getString(item, 'status');
    const status: Order['orderStatus'] =
      raw === 'pending' ||
      raw === 'processing' ||
      raw === 'confirmed' ||
      raw === 'packed' ||
      raw === 'shipped' ||
      raw === 'delivered' ||
      raw === 'cancelled'
        ? raw
        : 'pending';
    return {
      status,
      note: getString(item, 'note') || undefined,
      updatedByName: getString(item, 'updatedByName') || undefined,
      createdAt: getString(item, 'createdAt') || undefined,
    };
  });
};

const normalizeProduct = (p: unknown): Product => {
  const obj = isRecord(p) ? p : {};
  return {
    id: getString(obj, '_id') || getString(obj, 'id'),
    name: getString(obj, 'name'),
    description: getString(obj, 'description'),
    price: getNumber(obj, 'price'),
    category: getString(obj, 'category'),
    images: getStringArray(obj, 'images').map((img) => resolveBackendAssetUrl(img)).filter(Boolean),
    inStock: getBoolean(obj, 'inStock'),
    createdAt: getString(obj, 'createdAt') || new Date().toISOString(),
  };
};

const normalizeOrder = (o: unknown): Order => {
  const obj = isRecord(o) ? o : {};
  const productIdObj = isRecord(obj.productId) ? obj.productId : {};
  const userIdObj = isRecord(obj.userId) ? obj.userId : {};

  const paymentStatusRaw = getString(obj, 'paymentStatus');
  const paymentStatus: Order['paymentStatus'] =
    paymentStatusRaw === 'paid' || paymentStatusRaw === 'failed' || paymentStatusRaw === 'pending' ? paymentStatusRaw : 'pending';

  const orderStatusRaw = getString(obj, 'orderStatus');
  const orderStatus: Order['orderStatus'] =
    orderStatusRaw === 'pending' ||
    orderStatusRaw === 'processing' ||
    orderStatusRaw === 'confirmed' ||
    orderStatusRaw === 'packed' ||
    orderStatusRaw === 'shipped' ||
    orderStatusRaw === 'delivered' ||
    orderStatusRaw === 'cancelled'
      ? orderStatusRaw
      : 'pending';

  return {
    id: getString(obj, '_id') || getString(obj, 'id'),
    orderId: getString(obj, 'orderId'),
    trackingId: getString(obj, 'trackingId') || undefined,
    productId: getString(productIdObj, '_id') || getString(obj, 'productId'),
    productName: getString(obj, 'productName'),
    productImage: resolveBackendAssetUrl(getString(obj, 'productImage')),
    productPrice: getNumber(obj, 'productPrice'),
    quantity: getNumber(obj, 'quantity') || 1,
    subtotalAmount: getNumber(obj, 'subtotalAmount') || undefined,
    shippingFee: getNumber(obj, 'shippingFee') || undefined,
    totalAmount: getNumber(obj, 'totalAmount'),
    userId: getString(userIdObj, '_id') || getString(obj, 'userId'),
    userName: getString(obj, 'userName'),
    userEmail: getString(obj, 'userEmail'),
    userPhone: getString(obj, 'userPhone'),
    shippingAddress: getString(obj, 'shippingAddress'),
    orderNotes: getString(obj, 'orderNotes') || undefined,
    courierName: getString(obj, 'courierName') || undefined,
    awbNumber: getString(obj, 'awbNumber') || undefined,
    trackingUrl: getString(obj, 'trackingUrl') || undefined,
    trackingNotes: getString(obj, 'trackingNotes') || undefined,
    shippedAt: getString(obj, 'shippedAt') || undefined,
    deliveredAt: getString(obj, 'deliveredAt') || undefined,
    statusHistory: normalizeStatusHistory(obj),
    paymentStatus,
    orderStatus,
    upiTransactionId: getString(obj, 'upiTransactionId') || undefined,
    invoiceSentAt: getString(obj, 'invoiceSentAt') || undefined,
    cancellationReason: getString(obj, 'cancellationReason') || undefined,
    cancelledByRole: (getString(obj, 'cancelledByRole') as Order['cancelledByRole']) || undefined,
    cancelledAt: getString(obj, 'cancelledAt') || undefined,
    cancellationDetails: getString(obj, 'cancellationDetails') || undefined,
    cancellationDeductionPercent: getNumber(obj, 'cancellationDeductionPercent') || undefined,
    cancellationDeductionAmount: getNumber(obj, 'cancellationDeductionAmount') || undefined,
    refundableAmount: getNumber(obj, 'refundableAmount') || undefined,
    createdAt: getString(obj, 'createdAt') || new Date().toISOString(),
    updatedAt: getString(obj, 'updatedAt') || undefined,
  };
};

const getApiErrorMessage = (err: unknown, fallback: string) => {
  if (axios.isAxiosError(err)) {
    const data = err.response?.data;
    if (isRecord(data) && typeof data.message === 'string') return data.message;
    return err.message || fallback;
  }
  if (err instanceof Error) return err.message || fallback;
  return fallback;
};

interface ProductState {
  products: Product[];
  myOrders: Order[];
  adminOrders: Order[];
  trackedOrder: Order | null;
  isLoadingProducts: boolean;
  isLoadingOrders: boolean;
  isLoadingTrackedOrder: boolean;
  fetchProducts: () => Promise<void>;
  fetchProductById: (id: string) => Promise<Product | null>;
  fetchAdminProducts: () => Promise<void>;
  createProduct: (product: Omit<Product, 'id' | 'createdAt'>) => Promise<{ success: boolean; error?: string }>;
  updateProduct: (id: string, data: Partial<Product>) => Promise<{ success: boolean; error?: string }>;
  deleteProduct: (id: string) => Promise<{ success: boolean; error?: string }>;

  createOrder: (order: Omit<Order, 'id' | 'orderId' | 'createdAt' | 'userId'>) => Promise<{ success: boolean; data?: Order; error?: string }>;
  fetchMyOrders: () => Promise<void>;
  fetchAllOrders: () => Promise<void>;
  trackOrderById: (trackingId: string) => Promise<{ success: boolean; data?: Order; error?: string }>;
  verifyOrderPayment: (id: string) => Promise<{ success: boolean; error?: string }>;
  rejectOrderPayment: (id: string) => Promise<{ success: boolean; error?: string }>;
  cancelOrder: (id: string, reason: string, details?: string) => Promise<{ success: boolean; error?: string }>;
  updateOrderStatus: (id: string, status: Order['orderStatus']) => Promise<{ success: boolean; error?: string }>;
  updateOrderTracking: (id: string, data: Partial<Pick<Order, 'orderStatus' | 'courierName' | 'awbNumber' | 'trackingUrl' | 'trackingNotes'>>) => Promise<{ success: boolean; error?: string }>;
}

export const useProductStore = create<ProductState>()((set, get) => ({
  products: [],
  myOrders: [],
  adminOrders: [],
  trackedOrder: null,
  isLoadingProducts: false,
  isLoadingOrders: false,
  isLoadingTrackedOrder: false,

  fetchProducts: async () => {
    try {
      set({ isLoadingProducts: true });
      const res = await api.get('/products', { params: { withImages: true } });
      const products = (res.data?.data || []).map(normalizeProduct);
      set({ products, isLoadingProducts: false });
    } catch {
      set({ products: [], isLoadingProducts: false });
    }
  },

  fetchProductById: async (id) => {
    if (!id) return null;
    const existing = get().products.find((p) => p.id === id);
    if (existing) return existing;
    try {
      const res = await api.get(`/products/${id}`);
      const product = normalizeProduct(res.data?.data);
      if (!product.id) return null;
      set((state) => ({ products: [product, ...state.products.filter((p) => p.id !== product.id)] }));
      return product;
    } catch {
      return null;
    }
  },

  fetchAdminProducts: async () => {
    const token = useAuthStore.getState().token;
    if (!token) return;
    try {
      set({ isLoadingProducts: true });
      const res = await api.get('/products/all', { ...withAuth(token), params: { withImages: true } });
      const products = (res.data?.data || []).map(normalizeProduct);
      set({ products, isLoadingProducts: false });
    } catch {
      set({ isLoadingProducts: false });
    }
  },

  createProduct: async (product) => {
    const token = useAuthStore.getState().token;
    if (!token) return { success: false, error: 'Not authenticated' };
    try {
      const res = await api.post('/products', product, withAuth(token));
      const created = normalizeProduct(res.data?.data);
      set((state) => ({ products: [created, ...state.products] }));
      publishAppEvent('product:changed');
      return { success: true };
    } catch (err: unknown) {
      return { success: false, error: getApiErrorMessage(err, 'Create failed') };
    }
  },

  updateProduct: async (id, data) => {
    const token = useAuthStore.getState().token;
    if (!token) return { success: false, error: 'Not authenticated' };
    try {
      const res = await api.put(`/products/${id}`, data, withAuth(token));
      const updated = normalizeProduct(res.data?.data);
      set((state) => ({ products: state.products.map((p) => (p.id === id ? updated : p)) }));
      publishAppEvent('product:changed');
      return { success: true };
    } catch (err: unknown) {
      return { success: false, error: getApiErrorMessage(err, 'Update failed') };
    }
  },

  deleteProduct: async (id) => {
    const token = useAuthStore.getState().token;
    if (!token) return { success: false, error: 'Not authenticated' };
    try {
      await api.delete(`/products/${id}`, withAuth(token));
      set((state) => ({ products: state.products.filter((p) => p.id !== id) }));
      publishAppEvent('product:changed');
      return { success: true };
    } catch (err: unknown) {
      return { success: false, error: getApiErrorMessage(err, 'Delete failed') };
    }
  },

  createOrder: async (order) => {
    const token = useAuthStore.getState().token;
    const user = useAuthStore.getState().user;
    if (!token || !user) return { success: false, error: 'Not authenticated' };
    try {
      const res = await api.post('/orders', order, withAuth(token));
      const created = normalizeOrder(res.data?.data);
      set((state) => ({ myOrders: [created, ...state.myOrders] }));
      return { success: true, data: created };
    } catch (err: unknown) {
      return { success: false, error: getApiErrorMessage(err, 'Order failed') };
    }
  },

  fetchMyOrders: async () => {
    const token = useAuthStore.getState().token;
    if (!token) return;
    try {
      set({ isLoadingOrders: true });
      const res = await api.get('/orders/my', { ...withAuth(token), params: { withImages: true } });
      const myOrders = (res.data?.data || []).map(normalizeOrder);
      set({ myOrders, isLoadingOrders: false });
    } catch {
      set({ isLoadingOrders: false });
    }
  },

  fetchAllOrders: async () => {
    const token = useAuthStore.getState().token;
    if (!token) return;
    try {
      set({ isLoadingOrders: true });
      const res = await api.get('/orders/all', { ...withAuth(token), params: { withImages: true } });
      const adminOrders = (res.data?.data || []).map(normalizeOrder);
      set({ adminOrders, isLoadingOrders: false });
    } catch {
      set({ isLoadingOrders: false });
    }
  },

  trackOrderById: async (trackingId) => {
    const cleaned = String(trackingId || '').trim();
    if (!/^\d{5}$/.test(cleaned)) return { success: false, error: 'Please enter a valid 5-digit tracking id' };
    try {
      set({ isLoadingTrackedOrder: true });
      const res = await api.get(`/orders/track/${cleaned}`);
      const trackedOrder = normalizeOrder(res.data?.data);
      set({ trackedOrder, isLoadingTrackedOrder: false });
      return { success: true, data: trackedOrder };
    } catch (err: unknown) {
      set({ isLoadingTrackedOrder: false, trackedOrder: null });
      return { success: false, error: getApiErrorMessage(err, 'Order not found') };
    }
  },

  verifyOrderPayment: async (id) => {
    const token = useAuthStore.getState().token;
    if (!token) return { success: false, error: 'Not authenticated' };
    try {
      const res = await api.put(`/orders/${id}/verify`, {}, withAuth(token));
      const updated = normalizeOrder(res.data?.data);
      set((state) => ({ adminOrders: state.adminOrders.map((o) => (o.id === id ? updated : o)) }));
      return { success: true };
    } catch (err: unknown) {
      return { success: false, error: getApiErrorMessage(err, 'Verify failed') };
    }
  },

  rejectOrderPayment: async (id) => {
    const token = useAuthStore.getState().token;
    if (!token) return { success: false, error: 'Not authenticated' };
    try {
      const res = await api.put(`/orders/${id}/reject`, {}, withAuth(token));
      const updated = normalizeOrder(res.data?.data);
      set((state) => ({ adminOrders: state.adminOrders.map((o) => (o.id === id ? updated : o)) }));
      return { success: true };
    } catch (err: unknown) {
      return { success: false, error: getApiErrorMessage(err, 'Reject failed') };
    }
  },

  cancelOrder: async (id, reason, details) => {
    const token = useAuthStore.getState().token;
    if (!token) return { success: false, error: 'Not authenticated' };
    try {
      const res = await api.put(`/orders/${id}/cancel`, { reason, details }, withAuth(token));
      const updated = normalizeOrder(res.data?.data);
      set((state) => ({
        adminOrders: state.adminOrders.map((o) => (o.id === id ? updated : o)),
        myOrders: state.myOrders.map((o) => (o.id === id ? updated : o)),
        trackedOrder: state.trackedOrder?.id === id ? updated : state.trackedOrder,
      }));
      return { success: true };
    } catch (err: unknown) {
      return { success: false, error: getApiErrorMessage(err, 'Cancel failed') };
    }
  },

  updateOrderStatus: async (id, status) => {
    const token = useAuthStore.getState().token;
    if (!token) return { success: false, error: 'Not authenticated' };
    try {
      const res = await api.put(`/orders/${id}/status`, { status }, withAuth(token));
      const updated = normalizeOrder(res.data?.data);
      set((state) => ({ adminOrders: state.adminOrders.map((o) => (o.id === id ? updated : o)) }));
      return { success: true };
    } catch (err: unknown) {
      return { success: false, error: getApiErrorMessage(err, 'Update failed') };
    }
  },

  updateOrderTracking: async (id, data) => {
    const token = useAuthStore.getState().token;
    if (!token) return { success: false, error: 'Not authenticated' };
    try {
      const res = await api.put(`/orders/${id}/tracking`, {
        status: data.orderStatus,
        courierName: data.courierName,
        awbNumber: data.awbNumber,
        trackingUrl: data.trackingUrl,
        trackingNotes: data.trackingNotes,
      }, withAuth(token));
      const updated = normalizeOrder(res.data?.data);
      set((state) => ({
        adminOrders: state.adminOrders.map((o) => (o.id === id ? updated : o)),
        myOrders: state.myOrders.map((o) => (o.id === id ? updated : o)),
        trackedOrder: state.trackedOrder?.id === id ? updated : state.trackedOrder,
      }));
      return { success: true };
    } catch (err: unknown) {
      return { success: false, error: getApiErrorMessage(err, 'Tracking update failed') };
    }
  },
}));
