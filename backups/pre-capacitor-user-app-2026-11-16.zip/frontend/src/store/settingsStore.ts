import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import axios from 'axios';
import { api, resolveBackendAssetUrl, withAuth } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';
import { COMPANY_EMAIL, COMPANY_NAME, COMPANY_PHONE } from '@/lib/brand';

export interface AppSettings {
  siteName: string;
  motto: string;
  logoUrl: string;
  faviconUrl: string;
  metaTitle: string;
  metaDescription: string;
  metaKeywords: string;
  ogImageUrl: string;
  upiId: string;
  upiName: string;
  adminPhone: string;
  adminEmail: string;
  termsOfService: string;
  privacyPolicy: string;
  partnerTerms: string;
  partnerPolicies: string;
  hotelTaxPercent: number;
  shopEnabled: boolean;
  trackOrderEnabled: boolean;
}

interface SettingsState {
  settings: AppSettings;
  isLoading: boolean;
  refreshSettings: () => Promise<void>;
  saveSettings: (data: Partial<AppSettings>) => Promise<{ success: boolean; error?: string }>;
  uploadLogo: (file: File) => Promise<{ success: boolean; url?: string; error?: string }>;
  uploadFavicon: (file: File) => Promise<{ success: boolean; url?: string; error?: string }>;
}

const defaultSettings: AppSettings = {
  siteName: COMPANY_NAME,
  motto: 'Your Divine Guide to Braj',
  logoUrl: '',
  faviconUrl: '',
  metaTitle: COMPANY_NAME,
  metaDescription: 'Your Divine Guide to Braj',
  metaKeywords: 'Braj, Vrindavan, Mathura, Govardhan, Barsana, Gokul, hotels, rooms, cabs, tours, bookings, shop',
  ogImageUrl: '',
  upiId: '',
  upiName: COMPANY_NAME,
  adminPhone: COMPANY_PHONE,
  adminEmail: COMPANY_EMAIL,
  hotelTaxPercent: 12,
  shopEnabled: true,
  trackOrderEnabled: true,
  termsOfService: `1. Acceptance of Terms
By accessing and using Vrindavan Sarthi ("the Platform"), you agree to be bound by these Terms of Service. If you do not agree, please do not use the Platform.

2. Services
Vrindavan Sarthi provides an online platform for booking hotels, rooms, cabs, and tour packages across Braj. We act as an intermediary between users and service providers (hotels, cab drivers, tour operators).

3. User Accounts
You must provide accurate and complete information when creating an account. You are responsible for maintaining the confidentiality of your account credentials and for all activities under your account.

4. Bookings, Platform Fees & Payments
All bookings are subject to availability and partner/property confirmation. Hotel room bookings may include a 10% platform fee on the room booking amount. Dharamshala booking requests may include an admin-configured platform fee after the Dharamshala partner accepts the request. The partner may ask the customer to pay the room donation/contribution online with the platform fee or collect it at check-in, as shown on the booking payment screen. Booking confirmations are sent through the platform.

5. Cancellation & Refunds
Cancellation policies vary by service provider. Platform fees charged by Vrindavan Sarthi, including any Dharamshala platform fee and hotel room platform fee, are non-refundable when a booking is cancelled unless required by law or specifically approved by the admin team. Refunds for any other eligible amount, if applicable, will be processed within 7-10 business days after review. Dharamshala payments made directly to the Dharamshala are handled under that Dharamshala's own rules.

6. Partner Responsibilities
Partners listing hotels, rooms, cabs, or tours must provide accurate information. All listings are subject to admin verification. Misrepresentation may result in removal from the platform.

7. Limitation of Liability
Vrindavan Sarthi is not liable for the quality of services provided by third-party partners. We make every effort to verify listings but do not guarantee accuracy of all information.

8. Contact
For questions about these Terms, contact us at vrindavansarthi108@gmail.com or visit our Contact page.`,
  privacyPolicy: `1. Information We Collect
We collect personal information you provide during registration: name, email, phone number, address. For partners, we also collect business details including GST number and business address.

2. How We Use Your Information
Your information is used to: process bookings, communicate booking confirmations, improve our services, send relevant updates, and comply with legal obligations.

3. Data Sharing
We share necessary booking details with service providers (hotels, cab drivers) to fulfill your reservations. We do not sell your personal data to third parties.

4. Data Security
We implement industry-standard security measures to protect your personal information. However, no method of transmission over the Internet is 100% secure.

5. Cookies
We use cookies and local storage to maintain your session, remember preferences, and improve user experience on the platform.

6. Your Rights
You have the right to access, update, or delete your personal information at any time through your profile settings or by contacting our support team.

7. Contact Us
For privacy-related inquiries, contact us at vrindavansarthi108@gmail.com or through our Contact page.`,
  partnerTerms: `1. Listing Accuracy
Partners must list only genuine, lawful, owner-authorized hotels, rooms, cabs, and services. Images, room inventory, amenities, maps, pricing, policies, and availability must remain accurate.

2. Booking Handling
Confirmed bookings must be honored. Hotel partners acknowledge that hotel room bookings may include a 10% platform fee. Dharamshala partners choose during acceptance whether the room donation/contribution is paid online with the platform fee or collected at check-in. Partners must support guest arrival and keep check-in/check-out status updated.

3. Tax, Invoice, and Compliance
The property partner remains responsible for accommodation tax invoices, GST filing, licenses, and local compliance wherever applicable.

4. Payouts
Eligible payouts follow the platform ledger, minimum payout threshold, and scheduled settlement cycles.`,
  partnerPolicies: `1. Guest Privacy
Guest contact and identity details may be used only for servicing the booking and must not be misused or shared.

2. Customer Support
Partners must remain reachable on their registered phone number for confirmed booking coordination.

3. Property Rules
Partners must clearly publish check-in rules, ID requirements, cancellation policies, guest policies, and any property-specific restrictions.

4. Platform Updates
Admin may update partner policies from time to time. The latest published version is visible in the Partner Dashboard.`,
};

const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null;
const getString = (obj: Record<string, unknown>, key: string) => (typeof obj[key] === 'string' ? obj[key] : '');
const getNumber = (obj: Record<string, unknown>, key: string, fallback: number) => {
  const n = Number(obj[key]);
  return Number.isFinite(n) ? n : fallback;
};
const getBoolean = (obj: Record<string, unknown>, key: string, fallback: boolean) =>
  typeof obj[key] === 'boolean' ? obj[key] : fallback;
const normalizeBrandText = (value: string) =>
  value
    .replaceAll('VrindavanSarthi', COMPANY_NAME)
    .replace(/Vrindavan Sarthi Enterprises(?: Enterprises)*/g, COMPANY_NAME)
    .replace(/Vrindavan Sarthi(?! Enterprises)/g, COMPANY_NAME)
    .replaceAll('vrindavansarthi108@gmail.com', COMPANY_EMAIL)
    .replaceAll('sanjaysharma148@gmail.com', COMPANY_EMAIL)
    .replaceAll('+91 7351814747', COMPANY_PHONE)
    .replaceAll('7351814747', COMPANY_PHONE)
    .replaceAll('+91 9876543210', COMPANY_PHONE)
    .replaceAll('9876543210', COMPANY_PHONE)
    .replaceAll('+91 8679820256', COMPANY_PHONE);
const normalizeBrandValue = (value: string, fallback: string) => normalizeBrandText(value || fallback);

const normalizeSettings = (raw: unknown): AppSettings => {
  const obj = isRecord(raw) ? raw : {};
  return {
    ...defaultSettings,
    siteName: normalizeBrandValue(getString(obj, 'siteName'), defaultSettings.siteName),
    motto: normalizeBrandValue(getString(obj, 'motto'), defaultSettings.motto),
    logoUrl: resolveBackendAssetUrl(getString(obj, 'logoUrl')),
    faviconUrl: resolveBackendAssetUrl(getString(obj, 'faviconUrl')),
    metaTitle: normalizeBrandValue(getString(obj, 'metaTitle'), getString(obj, 'siteName') || defaultSettings.metaTitle),
    metaDescription: normalizeBrandValue(getString(obj, 'metaDescription'), getString(obj, 'motto') || defaultSettings.metaDescription),
    metaKeywords: getString(obj, 'metaKeywords') || defaultSettings.metaKeywords,
    ogImageUrl: resolveBackendAssetUrl(getString(obj, 'ogImageUrl')),
    upiId: getString(obj, 'upiId'),
    upiName: normalizeBrandValue(getString(obj, 'upiName'), defaultSettings.upiName),
    adminPhone: normalizeBrandValue(getString(obj, 'adminPhone'), defaultSettings.adminPhone),
    adminEmail: normalizeBrandValue(getString(obj, 'adminEmail'), defaultSettings.adminEmail),
    hotelTaxPercent: Math.min(50, Math.max(0, getNumber(obj, 'hotelTaxPercent', defaultSettings.hotelTaxPercent))),
    shopEnabled: getBoolean(obj, 'shopEnabled', defaultSettings.shopEnabled),
    trackOrderEnabled: getBoolean(obj, 'trackOrderEnabled', defaultSettings.trackOrderEnabled),
    termsOfService: normalizeBrandValue(getString(obj, 'termsOfService'), defaultSettings.termsOfService),
    privacyPolicy: normalizeBrandValue(getString(obj, 'privacyPolicy'), defaultSettings.privacyPolicy),
    partnerTerms: normalizeBrandValue(getString(obj, 'partnerTerms'), defaultSettings.partnerTerms),
    partnerPolicies: normalizeBrandValue(getString(obj, 'partnerPolicies'), defaultSettings.partnerPolicies),
  };
};

const getApiErrorMessage = (err: unknown, fallback: string) => {
  if (axios.isAxiosError(err)) {
    const data = err.response?.data;
    if (isRecord(data) && typeof data.message === 'string') return data.message;
    return err.message || fallback;
  }
  if (err instanceof Error) return err.message || fallback;
  return fallback;
};

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      settings: defaultSettings,
      isLoading: false,

      refreshSettings: async () => {
        try {
          set({ isLoading: true });
          const res = await api.get('/settings');
          const settings = normalizeSettings(res.data?.data);
          set({ settings, isLoading: false });
        } catch {
          set({ isLoading: false });
        }
      },

      saveSettings: async (data) => {
        const token = useAuthStore.getState().token;
        if (!token) return { success: false, error: 'Not authenticated' };
        try {
          const res = await api.put('/settings', data, withAuth(token));
          const settings = normalizeSettings(res.data?.data);
          set({ settings });
          return { success: true };
        } catch (err: unknown) {
          return { success: false, error: getApiErrorMessage(err, 'Failed to save settings') };
        }
      },

      uploadLogo: async (file) => {
        const token = useAuthStore.getState().token;
        if (!token) return { success: false, error: 'Not authenticated' };
        try {
          const form = new FormData();
          form.append('file', file);
          const res = await api.post('/settings/logo', form, withAuth(token));
          const settings = normalizeSettings(res.data?.data);
          set({ settings });
          return { success: true, url: typeof res.data?.url === 'string' ? res.data.url : settings.logoUrl };
        } catch (err: unknown) {
          return { success: false, error: getApiErrorMessage(err, 'Logo upload failed') };
        }
      },

      uploadFavicon: async (file) => {
        const token = useAuthStore.getState().token;
        if (!token) return { success: false, error: 'Not authenticated' };
        try {
          const form = new FormData();
          form.append('file', file);
          const res = await api.post('/settings/favicon', form, withAuth(token));
          const settings = normalizeSettings(res.data?.data);
          set({ settings });
          return { success: true, url: typeof res.data?.url === 'string' ? res.data.url : settings.faviconUrl };
        } catch (err: unknown) {
          return { success: false, error: getApiErrorMessage(err, 'Favicon upload failed') };
        }
      },
    }),
    {
      name: 'vvs-settings',
      merge: (persisted, current) => {
        const state = persisted && typeof persisted === 'object' ? persisted as Partial<SettingsState> : {};
        return {
          ...current,
          ...state,
          settings: normalizeSettings(state.settings),
        };
      },
    }
  )
);
