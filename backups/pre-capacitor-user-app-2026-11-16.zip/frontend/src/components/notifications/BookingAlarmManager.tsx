import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Bell, BellRing, Check, MonitorSmartphone, Settings, Volume2, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { api, withAuth } from '@/lib/api';
import type { User } from '@/types/auth.types';

type NotificationItem = {
  _id: string;
  title: string;
  message: string;
  priority?: 'normal' | 'high' | 'critical';
  eventType?: string;
  entityId?: string;
  bookingId?: string;
  alarmStatus?: 'created' | 'delivered' | 'alarming' | 'acknowledged' | 'expired';
  alarmExpiresAt?: string;
  acknowledgedAt?: string;
  createdAt?: string;
  metadata?: Record<string, unknown>;
};

type DeviceItem = {
  _id: string;
  deviceId: string;
  platform?: string;
  browser?: string;
  permissionStatus?: string;
  notificationEnabled?: boolean;
  alarmEnabled?: boolean;
  lastPushSuccessAt?: string;
  pushSubscriptionError?: string;
  lastSeenAt?: string;
};

type PushRegistrationResult = {
  subscription: PushSubscriptionJSON | null;
  configured: boolean;
};

type Props = {
  token: string | null;
  user: User | null;
  enabled?: boolean;
  viewPath: string;
  onNewBooking?: () => void;
};

const pollMs = 15_000;
const alarmSoundPath = '/alarm.mp3';
const alarmEventTypes = new Set(['BOOKING_CONFIRMED', 'DHARAMSHALA_PROPERTY_REVIEW', 'BOOKING_REQUIRES_ACTION']);

const getDeviceId = () => {
  const key = 'vvs_notification_device_id';
  const existing = localStorage.getItem(key);
  if (existing) return existing;
  const next = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  localStorage.setItem(key, next);
  return next;
};

const getPermissionStatus = () => {
  if (!('Notification' in window)) return 'unsupported';
  if (!window.isSecureContext) return 'unsupported';
  return Notification.permission;
};

const permissionCopy = {
  default: 'Important: allow notifications on this device. Repeat this on every mobile, laptop, desktop, and tablet used by admins or partners.',
  granted: 'Device notification permission is granted on this browser and device.',
  denied: 'Important: notifications are blocked in this device permission manager. Enable them from browser or site settings to receive booking alarms.',
  unsupported: 'Device notifications need a supported browser on HTTPS or localhost. In-app booking alarms still work while the app is open.',
};

const lockScreenCopy = {
  default: 'Allow browser notifications so locked-device alerts can use this phone or computer notification sound and vibration.',
  granted: 'Locked-device alerts use this browser or phone notification sound and vibration. The custom MP3 plays when the app is open.',
  denied: 'This device is blocking notification center alerts. Re-enable this site in browser or OS notification settings.',
  unsupported: 'Locked-device notification sound needs a supported browser on HTTPS or localhost.',
};

const getPlatform = () => navigator.platform || 'Browser';
const getBrowser = () => {
  const ua = navigator.userAgent;
  if (/Edg\//.test(ua)) return 'Edge';
  if (/Chrome\//.test(ua)) return 'Chrome';
  if (/Firefox\//.test(ua)) return 'Firefox';
  if (/Safari\//.test(ua)) return 'Safari';
  return 'Browser';
};

const urlBase64ToUint8Array = (base64String: string) => {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = `${base64String}${padding}`.replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  return Uint8Array.from([...rawData].map((char) => char.charCodeAt(0)));
};

const isActiveAlarm = (n: NotificationItem, now = Date.now()) => {
  if (n.priority !== 'critical' || !alarmEventTypes.has(String(n.eventType || ''))) return false;
  if (n.acknowledgedAt || n.alarmStatus === 'acknowledged') return false;
  const expires = n.alarmExpiresAt ? new Date(n.alarmExpiresAt).getTime() : 0;
  return !expires || expires > now;
};

const BookingAlarmManager = ({ token, user, enabled = true, viewPath, onNewBooking }: Props) => {
  const navigate = useNavigate();
  const deviceId = useMemo(getDeviceId, []);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const seenRef = useRef<Set<string>>(new Set());
  const dismissedRef = useRef<Set<string>>(new Set());
  const dismissedStorageKey = useMemo(() => `vvs_dismissed_booking_alerts_${user?.id || user?.email || 'guest'}`, [user?.id, user?.email]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [dismissedNotificationIds, setDismissedNotificationIds] = useState<Set<string>>(new Set());
  const [devices, setDevices] = useState<DeviceItem[]>([]);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(() => localStorage.getItem('vvs_booking_alarm_sound') !== 'off');
  const [alarmPlaybackUnlocked, setAlarmPlaybackUnlocked] = useState(() => localStorage.getItem('vvs_booking_alarm_playback_unlocked') === 'yes');
  const [permissionStatus, setPermissionStatus] = useState(getPermissionStatus);
  const [nowTick, setNowTick] = useState(Date.now());
  const visibleNotifications = useMemo(
    () => notifications.filter((n) => !dismissedNotificationIds.has(n._id)),
    [dismissedNotificationIds, notifications]
  );
  const activeAlarm = visibleNotifications.find((n) => isActiveAlarm(n, nowTick));
  const unreadCriticalCount = visibleNotifications.filter((n) => n.priority === 'critical' && !n.acknowledgedAt).length;
  const recentCritical = visibleNotifications.filter((n) => n.priority === 'critical' && alarmEventTypes.has(String(n.eventType || ''))).slice(0, 5);
  const shouldShowPermissionPrompt = permissionStatus !== 'granted';

  useEffect(() => {
    try {
      const stored = JSON.parse(localStorage.getItem(dismissedStorageKey) || '[]');
      const ids = new Set<string>(Array.isArray(stored) ? stored.filter((id) => typeof id === 'string') : []);
      dismissedRef.current = ids;
      setDismissedNotificationIds(ids);
    } catch {
      dismissedRef.current = new Set();
      setDismissedNotificationIds(new Set());
    }
  }, [dismissedStorageKey]);

  const persistDismissedNotifications = useCallback((ids: Set<string>) => {
    const compactIds = Array.from(ids).slice(-200);
    try {
      localStorage.setItem(dismissedStorageKey, JSON.stringify(compactIds));
    } catch {
      // Dismiss still works for the current page even if browser storage is unavailable.
    }
  }, [dismissedStorageKey]);

  const stopSound = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    audioRef.current = null;
  }, []);

  const startSound = useCallback(() => {
    if (!soundEnabled || !alarmPlaybackUnlocked || audioRef.current || !activeAlarm) return;
    try {
      const audio = new Audio(alarmSoundPath);
      audio.loop = true;
      audio.preload = 'auto';
      audioRef.current = audio;
      void audio.play().catch(() => {
        // Browser autoplay policy can block sound. Visual and persisted alerts remain active.
        if (audioRef.current === audio) audioRef.current = null;
      });
    } catch {
      // Visual and persisted alerts remain active if audio cannot be initialized.
    }
  }, [activeAlarm, alarmPlaybackUnlocked, soundEnabled]);

  const registerDevice = useCallback(async (
    permission = permissionStatus,
    alarmEnabled = soundEnabled,
    pushSubscription?: PushSubscriptionJSON | null
  ) => {
    if (!token || !enabled) return;
    await api.post('/notifications/devices', {
      deviceId,
      platform: getPlatform(),
      browser: getBrowser(),
      userAgent: navigator.userAgent,
      permissionStatus: permission,
      notificationEnabled: permission === 'granted' && Boolean(pushSubscription),
      alarmEnabled,
      pushSubscription,
    }, withAuth(token));
  }, [deviceId, enabled, permissionStatus, soundEnabled, token]);

  const ensurePushSubscription = useCallback(async (forceRefresh = false): Promise<PushRegistrationResult> => {
    if (!('serviceWorker' in navigator) || !('PushManager' in window) || !window.isSecureContext) {
      return { subscription: null, configured: false };
    }
    const configRes = await api.get('/notifications/push-config', withAuth(token));
    const publicKey = String(configRes.data?.data?.publicKey || '');
    const configured = Boolean(configRes.data?.data?.configured && publicKey);
    if (!configured) return { subscription: null, configured: false };

    await navigator.serviceWorker.register('/vrs-service-worker.js');
    const registration = await navigator.serviceWorker.ready;
    const existing = await registration.pushManager.getSubscription();
    if (existing && !forceRefresh) return { subscription: existing.toJSON(), configured: true };
    if (existing && forceRefresh) await existing.unsubscribe().catch(() => undefined);
    const subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(publicKey),
    });
    return { subscription: subscription.toJSON(), configured: true };
  }, [token]);

  const loadDevices = useCallback(async () => {
    if (!token || !enabled) return;
    try {
      const res = await api.get('/notifications/devices', withAuth(token));
      setDevices(Array.isArray(res.data?.data) ? res.data.data : []);
    } catch {
      // Device history is helpful, but the alarm path remains usable without it.
    }
  }, [enabled, token]);

  const loadNotifications = useCallback(async () => {
    if (!token || !enabled) return;
    try {
      const res = await api.get('/notifications', { ...withAuth(token), params: { limit: 50 } });
      const list = Array.isArray(res.data?.data) ? res.data.data : [];
      setNotifications(list);
      setNowTick(Date.now());
      const latestCritical = list.find((n: NotificationItem) => (
        !dismissedRef.current.has(n._id)
        && n.priority === 'critical'
        && alarmEventTypes.has(String(n.eventType || ''))
      ));
      if (latestCritical?._id && !seenRef.current.has(latestCritical._id)) {
        seenRef.current.add(latestCritical._id);
        if (!sessionStorage.getItem(`vvs_seen_alarm_${latestCritical._id}`)) {
          sessionStorage.setItem(`vvs_seen_alarm_${latestCritical._id}`, '1');
          const active = isActiveAlarm(latestCritical);
          toast.info(active ? (latestCritical.title || 'Booking confirmed') : 'Missed booking alert', {
            description: latestCritical.message,
          });
          onNewBooking?.();
          if (permissionStatus === 'granted') {
            try {
              new Notification(active ? (latestCritical.title || 'Booking confirmed') : 'Missed booking alert', {
                body: latestCritical.message,
                tag: latestCritical._id,
                requireInteraction: active,
                silent: false,
              });
            } catch {
              // In-app alarm still covers unsupported browser notification delivery.
            }
          }
        }
      }
    } catch {
      // Keep the existing visual/audio state if a poll fails.
    }
  }, [enabled, onNewBooking, permissionStatus, token]);

  useEffect(() => {
    if (!token || !enabled) {
      stopSound();
      return;
    }
    void registerDevice().catch(() => undefined);
    void loadDevices();
    void loadNotifications();
    const onVisibility = () => {
      if (document.visibilityState === 'visible') {
        void registerDevice().catch(() => undefined);
        void loadNotifications();
      }
    };
    document.addEventListener('visibilitychange', onVisibility);
    const id = window.setInterval(() => {
      if (document.visibilityState === 'visible') void loadNotifications();
    }, pollMs);
    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      window.clearInterval(id);
    };
  }, [enabled, loadDevices, loadNotifications, registerDevice, stopSound, token]);

  useEffect(() => {
    if (!token || !enabled || permissionStatus !== 'granted') return;
    void ensurePushSubscription()
      .then((result) => registerDevice('granted', soundEnabled, result.subscription))
      .then(() => loadDevices())
      .catch(() => undefined);
  }, [enabled, ensurePushSubscription, loadDevices, permissionStatus, registerDevice, soundEnabled, token]);

  useEffect(() => {
    if (activeAlarm) startSound();
    else stopSound();
    return stopSound;
  }, [activeAlarm, startSound, stopSound]);

  useEffect(() => {
    if (!activeAlarm?.alarmExpiresAt) return;
    const expiresAt = new Date(activeAlarm.alarmExpiresAt).getTime();
    const delay = Math.max(0, expiresAt - Date.now());
    const id = window.setTimeout(() => {
      setNowTick(Date.now());
      stopSound();
    }, delay + 100);
    return () => window.clearTimeout(id);
  }, [activeAlarm?._id, activeAlarm?.alarmExpiresAt, stopSound]);

  const requestPermission = async () => {
    let permission = getPermissionStatus();
    if (permission === 'unsupported') {
      toast.info('Device notifications require a supported browser on HTTPS or localhost');
      await registerDevice(permission).catch(() => undefined);
      return;
    }
    if (permission === 'default') {
      permission = await Notification.requestPermission();
    }
    setPermissionStatus(permission);
    let pushSubscription: PushSubscriptionJSON | null = null;
    if (permission === 'granted') {
      const result = await ensurePushSubscription(true).catch(() => ({ subscription: null, configured: false }));
      pushSubscription = result.subscription;
      if (!result.configured) toast.info('Web Push is not configured on this server yet');
      if (result.configured && !pushSubscription) toast.error('Could not register this device for push notifications');
    }
    await registerDevice(permission, soundEnabled, pushSubscription).catch(() => undefined);
    await loadDevices();
    if (permission === 'granted' && pushSubscription) toast.success('Booking device notifications enabled');
    if (permission === 'denied') toast.error('Device notifications are blocked in browser settings');
  };

  const requestAlarmPlaybackPermission = async () => {
    try {
      const audio = new Audio(alarmSoundPath);
      audio.loop = false;
      audio.preload = 'auto';
      audio.volume = 0.35;
      await audio.play();
      window.setTimeout(() => {
        audio.pause();
        audio.currentTime = 0;
      }, 900);
      setAlarmPlaybackUnlocked(true);
      setSoundEnabled(true);
      localStorage.setItem('vvs_booking_alarm_playback_unlocked', 'yes');
      localStorage.setItem('vvs_booking_alarm_sound', 'on');
      await registerDevice(permissionStatus, true).catch(() => undefined);
      await loadDevices();
      toast.success('Alarm playback enabled on this device');
    } catch {
      setAlarmPlaybackUnlocked(false);
      localStorage.removeItem('vvs_booking_alarm_playback_unlocked');
      toast.error('This browser blocked alarm playback. Tap again, keep the app open, or check browser audio settings.');
    }
  };

  const acknowledge = async (id?: string) => {
    const notificationId = id || activeAlarm?._id;
    if (!token || !notificationId) return;
    stopSound();
    try {
      const res = await api.post(`/notifications/${notificationId}/acknowledge`, { deviceId }, withAuth(token));
      const updated = res.data?.data;
      setNotifications((prev) => prev.map((n) => (n._id === notificationId ? { ...n, ...updated } : n)));
    } catch {
      toast.error('Could not acknowledge booking alert');
      void loadNotifications();
    }
  };

  const dismissNotification = async (id: string) => {
    if (!token || !id) return;
    if (activeAlarm?._id === id) stopSound();

    setDismissedNotificationIds((prev) => {
      const next = new Set(prev);
      next.add(id);
      dismissedRef.current = next;
      persistDismissedNotifications(next);
      return next;
    });
    setNotifications((prev) => prev.filter((n) => n._id !== id));

    try {
      await api.post(`/notifications/${id}/acknowledge`, { deviceId }, withAuth(token));
    } catch {
      toast.error('Could not remove booking alert');
    }
  };

  const revokeDevice = async (id: string) => {
    if (!token) return;
    try {
      await api.delete(`/notifications/devices/${encodeURIComponent(id)}`, withAuth(token));
      await loadDevices();
    } catch {
      toast.error('Could not revoke this device');
    }
  };

  const sendTestPush = async (id = deviceId) => {
    if (!token) return;
    try {
      await api.post(`/notifications/devices/${encodeURIComponent(id)}/test-push`, {}, withAuth(token));
      toast.success('Test notification sent to this device notification center');
      await loadDevices();
    } catch (err: any) {
      if (id === deviceId && permissionStatus === 'granted') {
        const result = await ensurePushSubscription(true).catch(() => ({ subscription: null, configured: false }));
        if (result.subscription) {
          await registerDevice('granted', soundEnabled, result.subscription).catch(() => undefined);
          try {
            await api.post(`/notifications/devices/${encodeURIComponent(id)}/test-push`, {}, withAuth(token));
            toast.success('Fresh mobile subscription saved. Test notification sent.');
            await loadDevices();
            return;
          } catch (retryErr: any) {
            toast.error(retryErr?.response?.data?.message || 'Could not send test notification after refreshing this device');
          }
        } else {
          toast.error('Could not create a fresh push subscription on this mobile browser');
        }
      } else {
        toast.error(err?.response?.data?.message || 'Could not send test notification to this device');
      }
      await loadDevices();
    }
  };

  const toggleSound = () => {
    if (!soundEnabled || !alarmPlaybackUnlocked) {
      void requestAlarmPlaybackPermission();
      return;
    }
    setSoundEnabled(false);
    localStorage.setItem('vvs_booking_alarm_sound', 'off');
    stopSound();
    void registerDevice(permissionStatus, false).catch(() => undefined);
  };

  const viewBooking = () => {
    if (activeAlarm) void acknowledge(activeAlarm._id);
    navigate(viewPath);
  };

  if (!enabled || !token || !user) return null;

  return (
    <>
      <div className="relative flex items-center gap-2">
        {shouldShowPermissionPrompt && (
          <button
            type="button"
            onClick={requestPermission}
            className="hidden rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-semibold text-amber-900 shadow-sm hover:bg-amber-100 lg:inline-flex"
            title="Important: enable booking alarm notifications on this device"
          >
            Enable Alerts
          </button>
        )}
        <button
          type="button"
          onClick={() => setSettingsOpen((v) => !v)}
          className="relative inline-flex h-9 w-9 items-center justify-center rounded-lg border border-white/20 bg-white/10 text-white hover:bg-white/20"
          aria-label="Booking alert settings"
          title="Booking alert settings"
        >
          {unreadCriticalCount > 0 ? <BellRing size={17} /> : <Bell size={17} />}
          {unreadCriticalCount > 0 && (
            <span className="absolute -right-1 -top-1 min-w-5 rounded-full bg-red-600 px-1 text-[10px] font-bold text-white">
              {unreadCriticalCount}
            </span>
          )}
        </button>
        {settingsOpen && (
          <div className="fixed inset-x-3 bottom-4 top-16 z-50 flex max-h-[calc(100dvh-5rem)] flex-col overflow-hidden rounded-lg border border-border bg-card text-foreground shadow-2xl sm:absolute sm:inset-auto sm:right-0 sm:top-11 sm:w-[min(92vw,390px)] sm:max-h-[min(82vh,680px)]">
            <div className="flex shrink-0 items-center justify-between border-b border-border px-4 py-3">
              <div className="min-w-0">
                <h2 className="font-heading text-base font-semibold">Booking Alerts</h2>
                <p className="mt-0.5 text-xs text-muted-foreground">Notifications, alarm sound, and registered devices</p>
              </div>
              <button type="button" onClick={() => setSettingsOpen(false)} className="ml-3 rounded p-2 hover:bg-muted" aria-label="Close settings">
                <X size={16} />
              </button>
            </div>
            <div className="min-h-0 flex-1 overflow-y-auto px-4 py-4 text-sm">
              <div className="space-y-3">
              {shouldShowPermissionPrompt && (
                <div className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-amber-950">
                  <p className="text-sm font-semibold">Notification permission is important</p>
                  <p className="mt-1 text-xs">Please enable it on every admin and partner device that uses this application.</p>
                </div>
              )}
              <button type="button" onClick={requestPermission} className="flex w-full items-start justify-between gap-3 rounded-md border border-border px-3 py-3 text-left hover:bg-muted">
                <span className="min-w-0">
                  <span className="block font-medium">Device notification center</span>
                  <span className="mt-1 block text-xs leading-5 text-muted-foreground">{lockScreenCopy[permissionStatus as keyof typeof lockScreenCopy]}</span>
                </span>
                <span className="shrink-0 rounded bg-muted px-2 py-1 text-[10px] font-semibold uppercase text-muted-foreground">{permissionStatus}</span>
              </button>
              {permissionStatus === 'granted' && (
                <button type="button" onClick={() => sendTestPush()} className="flex w-full items-center justify-between gap-3 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-3 text-left text-emerald-950 hover:bg-emerald-100">
                  <span className="min-w-0">
                    <span className="block font-medium">Send test phone notification</span>
                    <span className="mt-1 block text-xs leading-5">A real notification should appear in this device notification bar using the device notification sound.</span>
                  </span>
                  <Bell size={16} className="shrink-0" />
                </button>
              )}
              <p className="text-xs leading-5 text-muted-foreground">{permissionCopy[permissionStatus as keyof typeof permissionCopy]}</p>
              <button type="button" onClick={toggleSound} className="flex w-full items-start justify-between gap-3 rounded-md border border-border px-3 py-3 text-left hover:bg-muted">
                <span className="min-w-0">
                  <span className="block font-medium">Alarm ring playback</span>
                  <span className="mt-1 block text-xs leading-5 text-muted-foreground">
                    Tap to grant and test custom MP3 playback. This custom sound plays when the app is open; locked devices use the phone notification sound.
                  </span>
                </span>
                <span className="shrink-0 rounded bg-muted px-2 py-1 text-[10px] font-semibold uppercase text-muted-foreground">
                  {soundEnabled && alarmPlaybackUnlocked ? 'GRANTED' : 'ENABLE'}
                </span>
              </button>
              </div>
              <div className="mt-4 border-t border-border pt-4">
                <div className="mb-4">
                <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase text-muted-foreground">
                  <BellRing size={14} /> Recent Booking Alerts
                </div>
                <div className="space-y-2">
                  {recentCritical.length === 0 ? (
                    <p className="rounded-md border border-dashed border-border px-3 py-4 text-sm text-muted-foreground">No booking alerts yet.</p>
                  ) : recentCritical.map((item) => {
                    const active = isActiveAlarm(item, nowTick);
                    return (
                      <div key={item._id} className="rounded-md border border-border px-3 py-2">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="break-words text-sm font-medium leading-5">{item.title}</p>
                            <p className="mt-1 break-words text-xs leading-5 text-muted-foreground">{item.message}</p>
                          </div>
                          <div className="flex shrink-0 items-center gap-1">
                            <span className="rounded bg-muted px-2 py-0.5 text-[10px] uppercase text-muted-foreground">
                              {item.acknowledgedAt ? 'ack' : active ? 'active' : 'missed'}
                            </span>
                            <button
                              type="button"
                              onClick={(event) => {
                                event.preventDefault();
                                event.stopPropagation();
                                void dismissNotification(item._id);
                              }}
                              className="inline-flex h-7 w-7 items-center justify-center rounded text-muted-foreground hover:bg-muted hover:text-foreground"
                              aria-label="Remove booking alert"
                              title="Remove booking alert"
                            >
                              <X size={14} />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
                </div>
              <div className="border-t border-border pt-3">
                <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase text-muted-foreground">
                  <MonitorSmartphone size={14} /> Registered Devices
                </div>
                <div className="space-y-2">
                  {devices.length === 0 ? (
                    <p className="rounded-md border border-dashed border-border px-3 py-4 text-sm text-muted-foreground">This device will appear after alerts are enabled.</p>
                  ) : devices.map((device) => (
                    <div key={device._id} className="flex items-center justify-between gap-3 rounded-md bg-muted/50 px-3 py-3">
                      <div className="min-w-0">
                        <p className="break-words text-sm font-medium leading-5">{device.browser || 'Browser'} - {device.platform || 'Device'}</p>
                        <p className="mt-1 text-xs uppercase text-muted-foreground">
                          {device.permissionStatus || 'default'} / {device.notificationEnabled ? 'push on' : 'push off'}
                        </p>
                        {device.lastPushSuccessAt && (
                          <p className="mt-1 text-xs text-emerald-700">Last push sent: {new Date(device.lastPushSuccessAt).toLocaleString()}</p>
                        )}
                        {device.pushSubscriptionError && (
                          <p className="mt-1 break-words text-xs text-red-700">{device.pushSubscriptionError}</p>
                        )}
                      </div>
                      <div className="flex shrink-0 items-center gap-1">
                        {device.notificationEnabled && (
                          <button type="button" onClick={() => sendTestPush(device.deviceId)} className="rounded p-2 text-emerald-700 hover:bg-background" aria-label="Send test notification">
                            <Bell size={14} />
                          </button>
                        )}
                        <button type="button" onClick={() => revokeDevice(device.deviceId)} className="rounded p-2 text-muted-foreground hover:bg-background hover:text-foreground" aria-label="Revoke device">
                          <X size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          </div>
        )}
      </div>

      {activeAlarm && (
        <div role="alertdialog" aria-live="assertive" className="fixed inset-x-3 top-3 z-[80] mx-auto max-w-3xl rounded-lg border border-red-300 bg-white p-4 text-slate-950 shadow-2xl">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-red-600 text-white">
              <BellRing size={24} />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold uppercase text-red-700">Critical booking alert</p>
              <h2 className="font-heading text-lg font-semibold">{activeAlarm.title}</h2>
              <p className="mt-1 text-sm text-slate-700">{activeAlarm.message}</p>
            </div>
            <div className="flex shrink-0 flex-col gap-2 sm:flex-row">
              <button type="button" onClick={viewBooking} className="inline-flex min-h-10 items-center justify-center gap-2 rounded-md bg-slate-950 px-3 py-2 text-sm font-semibold text-white hover:bg-slate-800">
                <Settings size={15} /> View Booking
              </button>
              <button type="button" onClick={() => acknowledge(activeAlarm._id)} className="inline-flex min-h-10 items-center justify-center gap-2 rounded-md border border-slate-300 px-3 py-2 text-sm font-semibold hover:bg-slate-100">
                <Check size={15} /> Accept Alert
              </button>
            </div>
          </div>
          {shouldShowPermissionPrompt && (
            <button type="button" onClick={requestPermission} className="mt-3 inline-flex items-center gap-2 rounded-md border border-red-200 px-3 py-2 text-xs font-semibold text-red-700 hover:bg-red-50">
              <Bell size={14} /> Enable device notification center alerts
            </button>
          )}
          {(!soundEnabled || !alarmPlaybackUnlocked) && (
            <button type="button" onClick={toggleSound} className="mt-3 inline-flex items-center gap-2 text-xs font-semibold text-red-700">
              <Volume2 size={14} /> Grant alarm playback on this device
            </button>
          )}
        </div>
      )}
    </>
  );
};

export default BookingAlarmManager;
