import { useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Image as ImageIcon } from 'lucide-react';
import { resolveBackendAssetUrl } from '@/lib/api';

interface ImageCarouselProps {
  images: string[];
  alt: string;
  /** Auto-swap interval in ms. Default 3500. */
  intervalMs?: number;
  /** Container height classes. */
  heightClass?: string;
  /** Show small clickable thumbnails below */
  showThumbnails?: boolean;
}

/**
 * Modern detail-page carousel:
 *  - Auto-advances on a timer.
 *  - On hover, the timer pauses and the active slide follows the mouse position
 *    horizontally (move pointer left ↔ right to swap).
 *  - Includes glass-style nav arrows, gradient overlay, and dot indicators.
 */
const ImageCarousel = ({
  images,
  alt,
  intervalMs = 3500,
  heightClass = 'aspect-[4/3] h-auto min-h-[220px] max-h-[330px] sm:aspect-[16/10] sm:min-h-[260px] md:max-h-[360px] lg:aspect-[16/9]',
  showThumbnails = true,
}: ImageCarouselProps) => {
  const safe = (images && images.length > 0 ? images : ['/placeholder.svg']).map((img) => resolveBackendAssetUrl(img) || '/placeholder.svg');
  const [active, setActive] = useState(0);
  const [hovering, setHovering] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<number | null>(null);

  // Auto-advance when not hovering
  useEffect(() => {
    if (hovering || safe.length <= 1) return;
    timerRef.current = window.setInterval(() => {
      setActive((i) => (i + 1) % safe.length);
    }, intervalMs);
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
    };
  }, [hovering, safe.length, intervalMs]);

  // Hover-driven slide swap (mouse X position determines slide)
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (safe.length <= 1 || !containerRef.current) return;
    const { left, width } = containerRef.current.getBoundingClientRect();
    const ratio = Math.min(0.999, Math.max(0, (e.clientX - left) / width));
    const idx = Math.floor(ratio * safe.length);
    if (idx !== active) setActive(idx);
  };

  const prev = () => setActive((i) => (i - 1 + safe.length) % safe.length);
  const next = () => setActive((i) => (i + 1) % safe.length);

  return (
    <div className="space-y-3">
      <div
        ref={containerRef}
        onMouseEnter={() => setHovering(true)}
        onMouseLeave={() => setHovering(false)}
        onMouseMove={handleMouseMove}
        className={`relative w-full ${heightClass} overflow-hidden rounded-2xl premium-surface group`}
      >
        {/* Slides */}
        {safe.map((src, i) => (
          <img
            key={i}
            src={src}
            alt={`${alt} ${i + 1}`}
            width={1200}
            height={800}
            loading={i === 0 ? 'eager' : 'lazy'}
            decoding="async"
            fetchPriority={i === 0 ? 'high' : 'auto'}
            sizes="(min-width: 1024px) 65vw, 100vw"
            className={`absolute inset-0 w-full h-full object-cover transition-all duration-700 ease-out ${
              i === active ? 'opacity-100 scale-100' : 'opacity-0 scale-105'
            }`}
            onError={(e) => ((e.target as HTMLImageElement).src = '/placeholder.svg')}
          />
        ))}

        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-foreground/50 via-transparent to-transparent" />

        {/* Empty fallback */}
        {safe[0] === '/placeholder.svg' && (
          <div className="absolute inset-0 flex items-center justify-center text-muted-foreground/40">
            <ImageIcon size={48} />
          </div>
        )}

        {/* Arrows */}
        {safe.length > 1 && (
          <>
            <button
              type="button"
              onClick={prev}
              aria-label="Previous image"
              className="premium-icon-button absolute left-3 top-1/2 h-10 w-10 -translate-y-1/2 opacity-0 transition-opacity group-hover:opacity-100"
            >
              <ChevronLeft size={18} />
            </button>
            <button
              type="button"
              onClick={next}
              aria-label="Next image"
              className="premium-icon-button absolute right-3 top-1/2 h-10 w-10 -translate-y-1/2 opacity-0 transition-opacity group-hover:opacity-100"
            >
              <ChevronRight size={18} />
            </button>
          </>
        )}

        {/* Counter */}
        {safe.length > 1 && (
          <div className="absolute top-3 right-3 rounded-full border border-white/60 bg-white/95 px-3 py-1 font-body text-xs font-semibold text-foreground shadow-sm">
            {active + 1} / {safe.length}
          </div>
        )}

        {/* Dots */}
        {safe.length > 1 && (
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
            {safe.map((_, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setActive(i)}
                aria-label={`Go to image ${i + 1}`}
                className={`h-1.5 rounded-full transition-all ${
                  i === active ? 'w-6 bg-brand-gold' : 'w-1.5 bg-primary-foreground/70'
                }`}
              />
            ))}
          </div>
        )}
      </div>

      {/* Thumbnails */}
      {showThumbnails && safe.length > 1 && (
        <div className="flex gap-2 overflow-x-auto px-0.5 pb-1">
          {safe.map((src, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setActive(i)}
              className={`relative h-14 w-[4.5rem] flex-shrink-0 overflow-hidden rounded-xl border bg-white transition-all ${
                i === active ? 'border-brand-gold ring-2 ring-brand-gold/40' : 'border-border opacity-75 hover:opacity-100'
              }`}
            >
              <img src={src} alt="" width={160} height={128} loading="lazy" decoding="async" sizes="72px" className="w-full h-full object-cover" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default ImageCarousel;
